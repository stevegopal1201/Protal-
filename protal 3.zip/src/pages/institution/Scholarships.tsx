import { useState } from "react";
import { Badge } from "../../ui";

const SCHOLARSHIPS = [
  { id: 1, name: "UM Excellence Award", type: "Partial Funding", amount: "RM 8,000/yr", recipients: 50, deadline: "30 Sep 2026", status: "Active", applicants: 142, programmes: ["All Programmes"] },
  { id: 2, name: "UM STEM Bursary", type: "Partial Funding", amount: "RM 5,000/yr", recipients: 100, deadline: "15 Oct 2026", status: "Active", applicants: 88, programmes: ["Computer Science", "Engineering"] },
  { id: 3, name: "UM International Merit", type: "Fully Funded", amount: "RM 25,000/yr", recipients: 20, deadline: "31 Aug 2026", status: "Closed", applicants: 310, programmes: ["All Programmes"] },
  { id: 4, name: "UM Research Postgrad", type: "Fully Funded", amount: "RM 18,000/yr", recipients: 15, deadline: "1 Dec 2026", status: "Draft", applicants: 0, programmes: ["Masters", "PhD"] },
];

export default function InstitutionScholarships() {
  const [filter, setFilter] = useState("All");

  const filtered = filter === "All" ? SCHOLARSHIPS : SCHOLARSHIPS.filter(s => s.status === filter);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Scholarships</h1>
          <p className="text-slate-500 text-sm mt-0.5">{SCHOLARSHIPS.filter(s => s.status === "Active").length} active scholarships · {SCHOLARSHIPS.reduce((a, s) => a + s.applicants, 0)} total applicants</p>
        </div>
        <button className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl transition-colors">+ New Scholarship</button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { l: "Total Scholarships", v: SCHOLARSHIPS.length.toString(), c: "text-teal-600" },
          { l: "Active", v: SCHOLARSHIPS.filter(s => s.status === "Active").length.toString(), c: "text-green-600" },
          { l: "Total Applicants", v: SCHOLARSHIPS.reduce((a, s) => a + s.applicants, 0).toString(), c: "text-blue-600" },
          { l: "Total Recipients/yr", v: SCHOLARSHIPS.filter(s => s.status === "Active").reduce((a, s) => a + s.recipients, 0).toString(), c: "text-purple-600" },
        ].map(s => (
          <div key={s.l} className="bg-white rounded-2xl border border-slate-200 p-4 text-center">
            <p className={`text-2xl font-bold ${s.c}`}>{s.v}</p>
            <p className="text-xs text-slate-400 font-medium mt-1">{s.l}</p>
          </div>
        ))}
      </div>

      {/* Filter tabs */}
      <div className="flex gap-1">
        {["All", "Active", "Draft", "Closed"].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-colors ${filter === f ? "bg-teal-600 text-white" : "text-slate-500 bg-white border border-slate-200 hover:border-slate-300"}`}>
            {f}
            <span className={`ml-1.5 text-[10px] px-1.5 py-0.5 rounded-full font-bold ${filter === f ? "bg-teal-500" : "bg-slate-100 text-slate-500"}`}>
              {f === "All" ? SCHOLARSHIPS.length : SCHOLARSHIPS.filter(s => s.status === f).length}
            </span>
          </button>
        ))}
      </div>

      {/* Scholarship list */}
      <div className="space-y-3">
        {filtered.map(s => (
          <div key={s.id} className="bg-white rounded-2xl border border-slate-200 p-5 hover:border-teal-200 hover:shadow-sm transition-all">
            <div className="flex items-start justify-between gap-4 mb-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center text-xl shrink-0">🎓</div>
                <div>
                  <p className="text-sm font-bold text-slate-800">{s.name}</p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <Badge status={s.type} dot={false} />
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-500 font-medium">{s.amount}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-500">{s.recipients} recipients/yr</span>
                  </div>
                </div>
              </div>
              <Badge status={s.status} />
            </div>

            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="bg-slate-50 rounded-xl p-3 text-center">
                <p className="text-[9px] text-slate-400 uppercase font-semibold tracking-wide">Applicants</p>
                <p className="text-lg font-bold text-slate-800 mt-0.5">{s.applicants}</p>
              </div>
              <div className="bg-slate-50 rounded-xl p-3 text-center">
                <p className="text-[9px] text-slate-400 uppercase font-semibold tracking-wide">Deadline</p>
                <p className="text-xs font-bold text-slate-700 mt-1">{s.deadline}</p>
              </div>
              <div className="bg-slate-50 rounded-xl p-3 text-center">
                <p className="text-[9px] text-slate-400 uppercase font-semibold tracking-wide">Programmes</p>
                <p className="text-xs font-bold text-slate-700 mt-1 truncate">{s.programmes[0]}</p>
              </div>
            </div>

            <div className="flex gap-2">
              <button className="px-3 py-1.5 text-xs font-semibold text-teal-600 bg-teal-50 hover:bg-teal-100 rounded-xl transition-colors">View Applicants</button>
              <button className="px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-xl transition-colors">Edit</button>
              {s.status === "Draft" && (
                <button className="px-3 py-1.5 text-xs font-semibold text-green-700 bg-green-50 hover:bg-green-100 rounded-xl transition-colors">Publish</button>
              )}
              {s.status === "Active" && (
                <button className="px-3 py-1.5 text-xs font-semibold text-slate-400 bg-slate-50 hover:bg-slate-100 rounded-xl transition-colors">Close</button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
