import { institutionStats } from "../../data/mock";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

const appTrend = [
  { month: "Mar", apps: 120 }, { month: "Apr", apps: 185 }, { month: "May", apps: 240 },
  { month: "Jun", apps: 310 }, { month: "Jul", apps: 280 }, { month: "Aug", apps: 395 },
];
const progData = [
  { name: "CS", enrolled: 320, capacity: 400 },
  { name: "SE", enrolled: 210, capacity: 280 },
  { name: "DS", enrolled: 180, capacity: 200 },
  { name: "EE", enrolled: 150, capacity: 250 },
  { name: "ME", enrolled: 190, capacity: 220 },
];

export default function InstitutionDashboard() {
  return (
    <div className="p-6 space-y-5 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Institution Dashboard</h1>
          <p className="text-slate-500 text-sm mt-0.5">Universiti Malaya · Academic Year 2026/27</p>
        </div>
        <button className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl transition-colors">+ Add Programme</button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { l: "Total Applications", v: institutionStats.applications.toLocaleString(), d: "+12% vs last month", c: "text-blue-600", bg: "bg-blue-50" },
          { l: "Programme Views", v: institutionStats.views.toLocaleString(), d: "Profile views", c: "text-teal-600", bg: "bg-teal-50" },
          { l: "Active Programmes", v: institutionStats.programmes.toString(), d: "Across 8 faculties", c: "text-purple-600", bg: "bg-purple-50" },
          { l: "Conversion Rate", v: institutionStats.conversion, d: "App to enrolment", c: "text-green-600", bg: "bg-green-50" },
        ].map(stat => (
          <div key={stat.l} className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{stat.l}</p>
            <p className={`text-2xl font-bold mt-2 ${stat.c}`}>{stat.v}</p>
            <p className="text-[11px] text-slate-400 mt-1">{stat.d}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-4">Application Trend</p>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={appTrend}>
              <defs>
                <linearGradient id="tealGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0D9488" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#0D9488" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
              <Area type="monotone" dataKey="apps" stroke="#0D9488" strokeWidth={2.5} fill="url(#tealGrad)" dot={{ r: 4, fill: "#0D9488" }} name="Applications" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-4">Application Status</p>
          <div className="space-y-3">
            {[["Pending Review", 148, "bg-amber-400"], ["Interview", 45, "bg-purple-400"], ["Accepted", 320, "bg-green-400"], ["Rejected", 38, "bg-red-400"]].map(([l, v, c]) => (
              <div key={l as string}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-500">{l as string}</span>
                  <span className="font-semibold text-slate-700">{v as number}</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${c as string}`} style={{ width: `${Math.round(((v as number) / 300) * 100)}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-4">Programme Enrollment vs Capacity</p>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={progData} barGap={4}>
            <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
            <Bar dataKey="capacity" fill="#E2E8F0" radius={[4, 4, 0, 0]} name="Capacity" />
            <Bar dataKey="enrolled" fill="#0D9488" radius={[4, 4, 0, 0]} name="Enrolled" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
