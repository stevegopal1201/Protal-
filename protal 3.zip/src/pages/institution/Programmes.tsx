import { useState } from "react";
import { Badge } from "../../ui";

const PROGS = [
  { id: 1, name: "Bachelor of Computer Science", faculty: "Computing", mode: "Full-time", intake: "Sep / Mar", enrolled: 320, capacity: 400, status: "Active", match: 91 },
  { id: 2, name: "Bachelor of Software Engineering", faculty: "Computing", mode: "Full-time", intake: "Sep", enrolled: 210, capacity: 280, status: "Active", match: 87 },
  { id: 3, name: "Bachelor of Data Science", faculty: "Computing", mode: "Full-time / Part-time", intake: "Sep / Jan", enrolled: 180, capacity: 200, status: "Active", match: 84 },
  { id: 4, name: "Bachelor of Electrical Engineering", faculty: "Engineering", mode: "Full-time", intake: "Sep", enrolled: 150, capacity: 250, status: "Active", match: 78 },
  { id: 5, name: "Bachelor of Mechanical Engineering", faculty: "Engineering", mode: "Full-time", intake: "Sep", enrolled: 190, capacity: 220, status: "Active", match: 75 },
  { id: 6, name: "Master of Business Administration", faculty: "Business", mode: "Part-time / Full-time", intake: "Jan / Sep", enrolled: 95, capacity: 120, status: "Active", match: 70 },
];

export default function InstitutionProgrammes() {
  const [search, setSearch] = useState("");
  const [faculty, setFaculty] = useState("All");
  const faculties = ["All", ...Array.from(new Set(PROGS.map(p => p.faculty)))];
  const filtered = PROGS.filter(p =>
    (faculty === "All" || p.faculty === faculty) &&
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Programmes</h1>
          <p className="text-slate-500 text-sm mt-0.5">{PROGS.length} active programmes</p>
        </div>
        <button className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl transition-colors">+ Add Programme</button>
      </div>

      <div className="flex gap-3 flex-wrap">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search programmes…"
          className="flex-1 min-w-48 px-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl outline-none focus:border-teal-400 transition-colors" />
        <div className="flex gap-1.5">
          {faculties.map(f => (
            <button key={f} onClick={() => setFaculty(f)}
              className={`px-3 py-2 text-xs font-semibold rounded-xl transition-colors ${faculty === f ? "bg-teal-600 text-white" : "text-slate-500 bg-white border border-slate-200 hover:border-slate-300"}`}>{f}</button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {["Programme", "Faculty", "Mode", "Intake", "Enrollment", "AI Match", "Status", "Actions"].map(h => (
                <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filtered.map(p => (
              <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-4">
                  <p className="text-sm font-semibold text-slate-800">{p.name}</p>
                </td>
                <td className="px-4 py-4 text-xs text-slate-500">{p.faculty}</td>
                <td className="px-4 py-4 text-xs text-slate-500">{p.mode}</td>
                <td className="px-4 py-4 text-xs text-slate-500">{p.intake}</td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-teal-500 rounded-full" style={{ width: `${Math.round((p.enrolled / p.capacity) * 100)}%` }} />
                    </div>
                    <span className="text-xs text-slate-500">{p.enrolled}/{p.capacity}</span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <span className="text-sm font-bold text-green-600">{p.match}%</span>
                </td>
                <td className="px-4 py-4"><Badge status={p.status} /></td>
                <td className="px-4 py-4">
                  <div className="flex gap-1.5">
                    <button className="text-xs text-teal-600 font-semibold hover:underline">Edit</button>
                    <span className="text-slate-200">|</span>
                    <button className="text-xs text-slate-400 hover:text-slate-600">View</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
