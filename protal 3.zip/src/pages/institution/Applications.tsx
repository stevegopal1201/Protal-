import { useState } from "react";
import { Badge } from "../../ui";

const APPS = [
  { id: 1, name: "Ahmad bin Razali", ref: "APP-2026-0041", programme: "Bachelor of CS", intake: "Sep 2026", submitted: "12 Aug", status: "Submitted", match: 94, nationality: "MY" },
  { id: 2, name: "Priya Krishnan", ref: "APP-2026-0039", programme: "Bachelor of Data Science", intake: "Sep 2026", submitted: "11 Aug", status: "Under Review", match: 88, nationality: "MY" },
  { id: 3, name: "Chen Wei Xuan", ref: "APP-2026-0036", programme: "Bachelor of SE", intake: "Sep 2026", submitted: "9 Aug", status: "Interview", match: 91, nationality: "MY" },
  { id: 4, name: "Nurul Ain binti Hassan", ref: "APP-2026-0031", programme: "Bachelor of CS", intake: "Sep 2026", submitted: "6 Aug", status: "Accepted", match: 96, nationality: "MY" },
  { id: 5, name: "Raj Kumar", ref: "APP-2026-0028", programme: "Bachelor of EE", intake: "Sep 2026", submitted: "4 Aug", status: "Rejected", match: 62, nationality: "IN" },
  { id: 6, name: "Li Ming", ref: "APP-2026-0025", programme: "Master of MBA", intake: "Jan 2027", submitted: "3 Aug", status: "Draft", match: 77, nationality: "CN" },
];

const TABS = ["All", "Submitted", "Under Review", "Interview", "Accepted", "Rejected"];

export default function InstitutionApplications() {
  const [tab, setTab] = useState("All");
  const [search, setSearch] = useState("");
  const filtered = APPS.filter(a =>
    (tab === "All" || a.status === tab) &&
    (a.name.toLowerCase().includes(search.toLowerCase()) || a.programme.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Applications</h1>
          <p className="text-slate-500 text-sm mt-0.5">{APPS.length} applications this intake</p>
        </div>
        <button className="px-4 py-2.5 text-sm font-semibold text-teal-600 bg-teal-50 hover:bg-teal-100 rounded-xl transition-colors">Export CSV</button>
      </div>

      <div className="flex gap-2 flex-wrap items-center">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search applicants or programmes…"
          className="flex-1 min-w-48 px-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl outline-none focus:border-teal-400 transition-colors" />
        <div className="flex gap-1">
          {TABS.map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-3 py-2 text-xs font-semibold rounded-xl transition-colors ${tab === t ? "bg-teal-600 text-white" : "text-slate-500 bg-white border border-slate-200 hover:border-slate-300"}`}>{t}</button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {["Applicant", "Reference", "Programme", "Intake", "Submitted", "Match", "Status", "Actions"].map(h => (
                <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filtered.map(a => (
              <tr key={a.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-teal-700 text-white text-xs font-bold flex items-center justify-center shrink-0">
                      {a.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-800">{a.name}</p>
                      <p className="text-[10px] text-slate-400">{a.nationality}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-4 text-xs text-slate-400 font-mono">{a.ref}</td>
                <td className="px-4 py-4 text-xs text-slate-600 font-medium">{a.programme}</td>
                <td className="px-4 py-4 text-xs text-slate-500">{a.intake}</td>
                <td className="px-4 py-4 text-xs text-slate-500">{a.submitted}</td>
                <td className="px-4 py-4"><span className="text-sm font-bold text-green-600">{a.match}%</span></td>
                <td className="px-4 py-4"><Badge status={a.status} /></td>
                <td className="px-4 py-4">
                  <div className="flex gap-1.5">
                    <button className="text-xs text-teal-600 font-semibold hover:underline">Review</button>
                    <span className="text-slate-200">|</span>
                    <button className="text-xs text-slate-400 hover:text-slate-600">Message</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
