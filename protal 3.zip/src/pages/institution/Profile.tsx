import { useState } from "react";

const TABS = ["Overview", "Contact", "Programmes", "Settings"];

export default function InstitutionProfile() {
  const [tab, setTab] = useState("Overview");
  const [editing, setEditing] = useState(false);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-5">
      {/* Hero */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="h-28 w-full" style={{ background: "linear-gradient(135deg, #0B1F3A 0%, #0f4c75 60%, #0D9488 100%)" }} />
        <div className="px-6 pb-5">
          <div className="flex items-end justify-between -mt-10 mb-4">
            <div className="w-20 h-20 rounded-2xl bg-teal-600 border-4 border-white flex items-center justify-center text-white text-2xl font-bold shadow-lg shrink-0">UM</div>
            <div className="flex gap-2">
              <span className="px-3 py-1.5 bg-green-50 text-green-700 text-xs font-semibold rounded-full border border-green-200">✓ Verified Institution</span>
              <button
                onClick={() => setEditing(!editing)}
                className={`px-4 py-2 text-sm font-semibold rounded-xl transition-colors ${editing ? "bg-teal-600 text-white" : "border border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
                {editing ? "Save Changes" : "Edit Profile"}
              </button>
            </div>
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Universiti Malaya</h2>
            <p className="text-sm text-slate-400 mt-0.5">Kuala Lumpur, Malaysia · Public University</p>
            <div className="flex flex-wrap gap-2 mt-3">
              {["QS Top 100", "Research University", "Founded 1949", "MQA Accredited"].map(tag => (
                <span key={tag} className="px-2.5 py-1 bg-slate-100 text-slate-600 text-xs font-semibold rounded-full">{tag}</span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-white border border-slate-200 p-1 rounded-xl w-fit">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${tab === t ? "bg-teal-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === "Overview" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 space-y-5">
            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <p className="text-sm font-semibold text-slate-700 mb-4">Institution Details</p>
              <div className="grid grid-cols-2 gap-3">
                {[
                  ["Full Name", "Universiti Malaya"],
                  ["Short Name", "UM"],
                  ["Type", "Public University"],
                  ["Established", "1949"],
                  ["Location", "Kuala Lumpur"],
                  ["State", "Wilayah Persekutuan"],
                  ["Website", "um.edu.my"],
                  ["MQA Code", "KPT/JPT(R2/340/6/0128)"],
                ].map(([label, value]) => (
                  <div key={label} className="bg-slate-50 rounded-xl p-3">
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wide">{label}</p>
                    {editing ? (
                      <input defaultValue={value} className="w-full text-sm font-medium text-slate-700 bg-transparent border-b border-teal-300 outline-none mt-1" />
                    ) : (
                      <p className="text-sm font-medium text-slate-700 mt-0.5 truncate">{value}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <p className="text-sm font-semibold text-slate-700 mb-3">About</p>
              {editing ? (
                <textarea defaultValue="Universiti Malaya is a Malaysian public research university located in Kuala Lumpur. It is the oldest university in Malaysia, established in 1949 in Singapore before relocating to Kuala Lumpur in 1959." rows={4}
                  className="w-full text-sm text-slate-600 leading-relaxed bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:border-teal-400 resize-none" />
              ) : (
                <p className="text-sm text-slate-600 leading-relaxed">Universiti Malaya is a Malaysian public research university located in Kuala Lumpur. It is the oldest university in Malaysia, established in 1949 in Singapore before relocating to Kuala Lumpur in 1959.</p>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <p className="text-sm font-semibold text-slate-700 mb-3">Platform Stats</p>
              <div className="space-y-3">
                {[["Programmes Listed", "42"], ["Total Applications", "1,248"], ["Active Students", "28,000"], ["Scholarships Offered", "15"], ["Profile Views", "25,420"]].map(([l, v]) => (
                  <div key={l} className="flex justify-between items-center py-2 border-b border-slate-50 last:border-0">
                    <span className="text-xs text-slate-400 font-medium">{l}</span>
                    <span className="text-sm font-bold text-teal-700">{v}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-teal-600 to-teal-700 rounded-2xl p-5 text-white">
              <p className="text-sm font-semibold">Visibility Score</p>
              <p className="text-3xl font-bold mt-1">9.1 / 10</p>
              <p className="text-teal-200 text-xs mt-2 leading-relaxed">Your profile is highly optimised. Add faculty photos to reach 10/10.</p>
            </div>
          </div>
        </div>
      )}

      {tab === "Contact" && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 max-w-2xl space-y-4">
          <p className="text-sm font-semibold text-slate-700">Contact & Social</p>
          <div className="grid grid-cols-1 gap-3">
            {[
              ["General Enquiries Email", "enquiry@um.edu.my"],
              ["Admissions Email", "admission@um.edu.my"],
              ["Phone", "+603 7967 7022"],
              ["Address", "Jalan Universiti, Lembah Pantai, 50603 KL"],
              ["Facebook", "facebook.com/universiti.malaya"],
              ["LinkedIn", "linkedin.com/school/universiti-malaya"],
            ].map(([label, value]) => (
              <div key={label} className="flex items-center gap-3 bg-slate-50 rounded-xl p-3">
                <p className="text-xs font-semibold text-slate-400 w-44 shrink-0">{label}</p>
                {editing ? (
                  <input defaultValue={value} className="flex-1 text-sm font-medium text-slate-700 bg-transparent border-b border-teal-300 outline-none" />
                ) : (
                  <p className="text-sm font-medium text-slate-700 flex-1">{value}</p>
                )}
              </div>
            ))}
          </div>
          {editing && (
            <button onClick={() => setEditing(false)} className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl transition-colors">Save Contact</button>
          )}
        </div>
      )}

      {tab === "Programmes" && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <p className="text-sm font-semibold text-slate-700">Listed Programmes</p>
            <button className="px-3 py-1.5 text-xs font-semibold text-teal-600 bg-teal-50 hover:bg-teal-100 rounded-xl transition-colors">+ Add Programme</button>
          </div>
          <div className="divide-y divide-slate-50">
            {[
              { name: "Bachelor of Computer Science", faculty: "Computing", mode: "Full-time", status: "Active" },
              { name: "Bachelor of Software Engineering", faculty: "Computing", mode: "Full-time", status: "Active" },
              { name: "Bachelor of Data Science", faculty: "Computing", mode: "Full-time / Part-time", status: "Active" },
              { name: "Bachelor of Electrical Engineering", faculty: "Engineering", mode: "Full-time", status: "Active" },
              { name: "Master of Business Administration", faculty: "Business", mode: "Part-time / Full-time", status: "Active" },
            ].map(p => (
              <div key={p.name} className="flex items-center gap-4 px-5 py-4 hover:bg-slate-50 transition-colors">
                <div className="w-9 h-9 rounded-xl bg-teal-50 flex items-center justify-center text-lg shrink-0">📚</div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-800">{p.name}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{p.faculty} · {p.mode}</p>
                </div>
                <span className="text-xs font-semibold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">{p.status}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "Settings" && (
        <div className="max-w-2xl space-y-4">
          {[
            { label: "Public Profile Visibility", desc: "Show your institution on the student-facing portal", on: true },
            { label: "Accept Online Applications", desc: "Allow students to apply through Edvora", on: true },
            { label: "Show Scholarship Listings", desc: "Display scholarship opportunities to students", on: true },
            { label: "Email Notifications", desc: "Receive alerts for new applications and enquiries", on: false },
          ].map(setting => (
            <div key={setting.label} className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-800">{setting.label}</p>
                <p className="text-xs text-slate-400 mt-0.5">{setting.desc}</p>
              </div>
              <button className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${setting.on ? "bg-teal-500" : "bg-slate-200"}`}>
                <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${setting.on ? "left-5" : "left-0.5"}`} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
