import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";

const enrollTrend = [
  { year: "2022", cs: 280, se: 180, ds: 120, ee: 160 },
  { year: "2023", cs: 295, se: 195, ds: 145, ee: 155 },
  { year: "2024", cs: 308, se: 202, ds: 162, ee: 148 },
  { year: "2025", cs: 315, se: 208, ds: 174, ee: 151 },
  { year: "2026", cs: 320, se: 210, ds: 180, ee: 150 },
];

const demographicData = [
  { group: "Male", value: 58 }, { group: "Female", value: 42 },
];

const nationData = [
  { name: "Local", value: 72 }, { name: "International", value: 28 },
];

const COLORS = ["#0D9488", "#2563EB", "#7C3AED", "#D97706"];

export default function InstitutionAnalytics() {
  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Analytics</h1>
        <p className="text-slate-500 text-sm mt-0.5">Programme performance and student demographics</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[["Total Enrolled", "1,050", "+5.2%"], ["Avg GPA", "3.41", "+0.08"], ["Completion Rate", "87%", "+2%"], ["Placement Rate", "94%", "+1.5%"]].map(([l, v, d]) => (
          <div key={l} className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{l}</p>
            <p className="text-2xl font-bold text-slate-900 mt-2">{v}</p>
            <p className="text-xs text-green-500 font-semibold mt-1">{d} YoY</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-4">Enrollment Trend by Programme</p>
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={enrollTrend}>
            <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
            <XAxis dataKey="year" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            {["cs", "se", "ds", "ee"].map((k, i) => (
              <Line key={k} type="monotone" dataKey={k} stroke={COLORS[i]} strokeWidth={2.5} dot={{ r: 3 }} name={k.toUpperCase()} />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-4">Gender Distribution</p>
          <div className="space-y-3">
            {demographicData.map((d, i) => (
              <div key={d.group}>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-slate-500 font-medium">{d.group}</span>
                  <span className="font-bold text-slate-800">{d.value}%</span>
                </div>
                <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{ width: `${d.value}%`, backgroundColor: COLORS[i] }} />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-5">
            <p className="text-sm font-semibold text-slate-700 mb-3">Local vs International</p>
            <div className="space-y-3">
              {nationData.map((d, i) => (
                <div key={d.name}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-slate-500 font-medium">{d.name}</span>
                    <span className="font-bold text-slate-800">{d.value}%</span>
                  </div>
                  <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${d.value}%`, backgroundColor: i === 0 ? "#0D9488" : "#7C3AED" }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-4">Graduate Employment by Programme</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={[
              { prog: "CS", rate: 97 }, { prog: "SE", rate: 95 }, { prog: "DS", rate: 93 },
              { prog: "EE", rate: 89 }, { prog: "ME", rate: 88 }, { prog: "MBA", rate: 91 },
            ]} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" horizontal={false} />
              <XAxis type="number" domain={[70, 100]} tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} unit="%" />
              <YAxis dataKey="prog" type="category" tick={{ fontSize: 11, fill: "#64748B" }} axisLine={false} tickLine={false} width={36} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} formatter={(v) => [`${v}%`, "Placement Rate"]} />
              <Bar dataKey="rate" fill="#0D9488" radius={[0, 4, 4, 0]} name="Placement Rate" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
