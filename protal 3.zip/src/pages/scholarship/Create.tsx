import { useState } from "react";
import { useNavigate } from "react-router";

const STEPS = ["Basic Info", "Eligibility", "Funding", "Review"];

export default function ScholarshipCreate() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    name: "", provider: "", type: "Full", amount: "", recipients: "",
    deadline: "", minGPA: "3.0", nationality: "Malaysian", field: "Any",
    description: "", requirements: "",
  });

  const set = (k: keyof typeof form, v: string) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Create Scholarship</h1>
        <p className="text-slate-500 text-sm mt-0.5">Add a new scholarship offering to the platform</p>
      </div>

      {/* Progress */}
      <div className="flex items-center gap-0">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${i < step ? "bg-amber-500 text-white" : i === step ? "bg-amber-500 text-white ring-4 ring-amber-100" : "bg-slate-100 text-slate-400"}`}>
                {i < step ? "✓" : i + 1}
              </div>
              <p className="text-[9px] mt-1 text-center font-medium text-slate-500 whitespace-nowrap">{s}</p>
            </div>
            {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 mx-2 mb-4 ${i < step ? "bg-amber-500" : "bg-slate-200"}`} />}
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
        {step === 0 && (
          <>
            <p className="text-sm font-semibold text-slate-700">Basic Information</p>
            {[["Scholarship Name", "name", "text", "e.g. Future Technology Scholarship"], ["Provider Organisation", "provider", "text", "e.g. ABC Education Foundation"], ["Application Deadline", "deadline", "date", ""]].map(([l, k, t, ph]) => (
              <div key={k as string}>
                <label className="block text-xs font-semibold text-slate-500 mb-1">{l as string}</label>
                <input type={t as string} value={form[k as keyof typeof form]} onChange={e => set(k as keyof typeof form, e.target.value)}
                  placeholder={ph as string}
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-400 focus:bg-white transition-all" />
              </div>
            ))}
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">Scholarship Type</label>
              <div className="flex gap-2">
                {["Full", "Partial", "Bursary"].map(t => (
                  <button key={t} onClick={() => set("type", t)}
                    className={`flex-1 py-2.5 text-xs font-semibold rounded-xl border transition-colors ${form.type === t ? "border-amber-500 bg-amber-50 text-amber-700" : "border-slate-200 text-slate-500 hover:border-slate-300"}`}>{t}</button>
                ))}
              </div>
            </div>
          </>
        )}
        {step === 1 && (
          <>
            <p className="text-sm font-semibold text-slate-700">Eligibility Criteria</p>
            {[["Minimum GPA", "minGPA", ["2.5", "3.0", "3.5", "3.8"]], ["Nationality", "nationality", ["Malaysian", "International", "Any"]], ["Field of Study", "field", ["Any", "STEM", "Computing", "Engineering", "Business", "Arts"]]].map(([l, k, opts]) => (
              <div key={k as string}>
                <label className="block text-xs font-semibold text-slate-500 mb-1">{l as string}</label>
                <div className="flex gap-2 flex-wrap">
                  {(opts as string[]).map(o => (
                    <button key={o} onClick={() => set(k as keyof typeof form, o)}
                      className={`px-3 py-2 text-xs font-semibold rounded-xl border transition-colors ${form[k as keyof typeof form] === o ? "border-amber-500 bg-amber-50 text-amber-700" : "border-slate-200 text-slate-500 hover:border-slate-300"}`}>{o}</button>
                  ))}
                </div>
              </div>
            ))}
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">Additional Requirements</label>
              <textarea value={form.requirements} onChange={e => set("requirements", e.target.value)} rows={3}
                placeholder="e.g. Must be first-generation university student…"
                className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-400 resize-none transition-all" />
            </div>
          </>
        )}
        {step === 2 && (
          <>
            <p className="text-sm font-semibold text-slate-700">Funding Details</p>
            {[["Award Amount (RM/year)", "amount", "e.g. 25000"], ["Number of Recipients", "recipients", "e.g. 10"]].map(([l, k, ph]) => (
              <div key={k as string}>
                <label className="block text-xs font-semibold text-slate-500 mb-1">{l as string}</label>
                <input type="number" value={form[k as keyof typeof form]} onChange={e => set(k as keyof typeof form, e.target.value)}
                  placeholder={ph as string}
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-400 focus:bg-white transition-all" />
              </div>
            ))}
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">Description</label>
              <textarea value={form.description} onChange={e => set("description", e.target.value)} rows={4}
                placeholder="Describe the scholarship, mission, and what you're looking for in candidates…"
                className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-400 resize-none transition-all" />
            </div>
          </>
        )}
        {step === 3 && (
          <>
            <p className="text-sm font-semibold text-slate-700">Review & Publish</p>
            <div className="space-y-2">
              {[["Name", form.name || "Not set"], ["Provider", form.provider || "Not set"], ["Type", form.type], ["Amount", form.amount ? `RM ${Number(form.amount).toLocaleString()}/yr` : "Not set"], ["Recipients", form.recipients || "Not set"], ["Deadline", form.deadline || "Not set"], ["Min GPA", form.minGPA], ["Nationality", form.nationality], ["Field", form.field]].map(([l, v]) => (
                <div key={l as string} className="flex justify-between py-2 border-b border-slate-50 last:border-0">
                  <span className="text-xs text-slate-400 font-medium">{l as string}</span>
                  <span className={`text-xs font-semibold ${v === "Not set" ? "text-red-400" : "text-slate-700"}`}>{v as string}</span>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      <div className="flex gap-3">
        {step > 0 && (
          <button onClick={() => setStep(s => s - 1)} className="px-6 py-2.5 text-sm font-semibold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors">Back</button>
        )}
        <button
          onClick={() => step < 3 ? setStep(s => s + 1) : navigate("/scholarship")}
          className="flex-1 py-2.5 text-sm font-semibold bg-amber-500 hover:bg-amber-600 text-white rounded-xl transition-colors">
          {step < 3 ? "Continue" : "Publish Scholarship"}
        </button>
      </div>
    </div>
  );
}
