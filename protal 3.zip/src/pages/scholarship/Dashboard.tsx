import { scholarships } from "../../data/mock";
import { Badge } from "../../ui";

const STATS = [
  { l: "Active Scholarships", v: "4", c: "text-amber-600" },
  { l: "Total Applicants", v: "1,240", c: "text-blue-600" },
  { l: "Awarded This Year", v: "86", c: "text-green-600" },
  { l: "Total Disbursed", v: "RM 4.3M", c: "text-purple-600" },
];

export default function ScholarshipDashboard() {
  return (
    <div className="p-6 max-w-5xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Scholarship Dashboard</h1>
          <p className="text-slate-500 text-sm mt-0.5">ABC Education Foundation · 2026</p>
        </div>
        <button className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white text-sm font-semibold rounded-xl transition-colors">+ New Scholarship</button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {STATS.map(s => (
          <div key={s.l} className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{s.l}</p>
            <p className={`text-2xl font-bold mt-2 ${s.c}`}>{s.v}</p>
          </div>
        ))}
      </div>

      <h2 className="text-base font-semibold text-slate-800">Active Scholarships</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {scholarships.map(s => (
          <div key={s.id} className="bg-white rounded-2xl border border-slate-200 p-5 hover:border-amber-200 hover:shadow-sm transition-all">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="text-sm font-semibold text-slate-800">{s.name}</p>
                <p className="text-xs text-slate-400 mt-0.5">{s.provider}</p>
              </div>
              <Badge status={s.type} dot={false} />
            </div>
            <div className="grid grid-cols-3 gap-2 mb-3">
              {[["Tuition", s.tuition], ["Recipients", s.recipients.toString()], ["Deadline", s.deadline]].map(([l, v]) => (
                <div key={l as string} className="bg-slate-50 rounded-xl p-2 text-center">
                  <p className="text-[9px] text-slate-400 uppercase font-semibold">{l as string}</p>
                  <p className="text-xs font-bold text-slate-700 mt-0.5">{v as string}</p>
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-2">
              <button className="flex-1 py-2 text-xs font-semibold text-amber-600 bg-amber-50 hover:bg-amber-100 rounded-xl transition-colors">View Applicants</button>
              <button className="flex-1 py-2 text-xs font-semibold text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-xl transition-colors">Edit</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
