import { useState } from "react";

const LOGS = [
  { id: 1, action: "User account suspended", actor: "admin@edvora.my", target: "raj@example.com", ip: "103.28.91.4", time: "2 min ago", level: "Warning" },
  { id: 2, action: "Scholarship published", actor: "susan@foundation.org", target: "Future Tech Scholarship", ip: "180.210.44.12", time: "15 min ago", level: "Info" },
  { id: 3, action: "Institution approved", actor: "admin@edvora.my", target: "HELP University", ip: "103.28.91.4", time: "1 hr ago", level: "Info" },
  { id: 4, action: "Bulk export triggered", actor: "datuk@gov.my", target: "applications_2026.csv", ip: "60.48.22.91", time: "2 hr ago", level: "Info" },
  { id: 5, action: "Failed login attempt (x5)", actor: "unknown", target: "admin@edvora.my", ip: "194.165.16.8", time: "3 hr ago", level: "Critical" },
  { id: 6, action: "AI agent restarted", actor: "system", target: "Document Verifier v3.1.2", ip: "internal", time: "4 hr ago", level: "Warning" },
  { id: 7, action: "Programme created", actor: "um-admin@um.edu.my", target: "B.Sc Cybersecurity", ip: "203.106.88.2", time: "5 hr ago", level: "Info" },
  { id: 8, action: "Student data export", actor: "nasser@gov.my", target: "students_selangor.csv", ip: "60.48.22.91", time: "6 hr ago", level: "Info" },
  { id: 9, action: "System backup completed", actor: "system", target: "db-backup-20260826.sql", ip: "internal", time: "8 hr ago", level: "Info" },
  { id: 10, action: "PayNet integration error", actor: "system", target: "PayNet Gateway", ip: "internal", time: "9 hr ago", level: "Critical" },
];

const LEVELS = ["All", "Info", "Warning", "Critical"];

export default function AuditLog() {
  const [level, setLevel] = useState("All");
  const [search, setSearch] = useState("");

  const filtered = LOGS.filter(l =>
    (level === "All" || l.level === level) &&
    (l.action.toLowerCase().includes(search.toLowerCase()) || l.actor.toLowerCase().includes(search.toLowerCase()))
  );

  const levelStyle = (lv: string) => {
    if (lv === "Critical") return "bg-red-50 text-red-700 border-red-200";
    if (lv === "Warning") return "bg-amber-50 text-amber-700 border-amber-200";
    return "bg-blue-50 text-blue-700 border-blue-200";
  };

  const levelDot = (lv: string) => {
    if (lv === "Critical") return "bg-red-500";
    if (lv === "Warning") return "bg-amber-500";
    return "bg-blue-400";
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Audit Log</h1>
          <p className="text-slate-500 text-sm mt-0.5">All system and admin actions · Last 24 hours</p>
        </div>
        <button className="px-4 py-2 text-xs font-semibold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors">Export Log</button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[["Info", LOGS.filter(l => l.level === "Info").length, "text-blue-600", "bg-blue-50"],
          ["Warnings", LOGS.filter(l => l.level === "Warning").length, "text-amber-600", "bg-amber-50"],
          ["Critical", LOGS.filter(l => l.level === "Critical").length, "text-red-600", "bg-red-50"]].map(([l, v, c, bg]) => (
          <div key={l as string} className={`rounded-2xl border p-4 text-center ${bg as string} border-slate-200`}>
            <p className={`text-2xl font-bold ${c as string}`}>{v as number}</p>
            <p className="text-xs font-semibold text-slate-500 mt-1">{l as string} events</p>
          </div>
        ))}
      </div>

      <div className="flex gap-3 flex-wrap">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search actions or actors…"
          className="flex-1 min-w-48 px-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl outline-none focus:border-purple-400 transition-colors" />
        <div className="flex gap-1.5">
          {LEVELS.map(lv => (
            <button key={lv} onClick={() => setLevel(lv)}
              className={`px-3 py-2 text-xs font-semibold rounded-xl transition-colors ${level === lv ? "bg-purple-600 text-white" : "text-slate-500 bg-white border border-slate-200 hover:border-slate-300"}`}>{lv}</button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="divide-y divide-slate-50">
          {filtered.map(log => (
            <div key={log.id} className="flex items-start gap-4 px-5 py-4 hover:bg-slate-50 transition-colors">
              <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${levelDot(log.level)}`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-sm font-semibold text-slate-800">{log.action}</p>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${levelStyle(log.level)}`}>{log.level}</span>
                </div>
                <div className="flex items-center gap-3 mt-1 text-[11px] text-slate-400 flex-wrap">
                  <span>Actor: <span className="font-medium text-slate-600">{log.actor}</span></span>
                  <span>·</span>
                  <span>Target: <span className="font-medium text-slate-600">{log.target}</span></span>
                  <span>·</span>
                  <span>IP: <span className="font-mono text-slate-500">{log.ip}</span></span>
                </div>
              </div>
              <span className="text-[11px] text-slate-400 shrink-0">{log.time}</span>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="py-16 text-center text-slate-400 text-sm">No matching log entries</div>
          )}
        </div>
      </div>
    </div>
  );
}
