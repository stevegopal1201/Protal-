import { useState } from "react";
import { Badge } from "../../ui";

const USERS = [
  { id: 1, name: "Steve Tan Wei Ming", email: "steve@example.com", role: "Student", joined: "10 Aug 2026", status: "Active", apps: 3 },
  { id: 2, name: "Ahmad bin Razali", email: "ahmad@um.edu.my", role: "Institution", joined: "1 Mar 2026", status: "Active", apps: 0 },
  { id: 3, name: "Dr. Lim Bee Hong", email: "lim@um.edu.my", role: "Institution", joined: "1 Jan 2026", status: "Active", apps: 0 },
  { id: 4, name: "Priya Krishnan", email: "priya@example.com", role: "Student", joined: "8 Aug 2026", status: "Active", apps: 2 },
  { id: 5, name: "Datuk Mohd Nasser", email: "nasser@gov.my", role: "Government", joined: "15 Apr 2026", status: "Active", apps: 0 },
  { id: 6, name: "Susan Ooi", email: "susan@foundation.org", role: "Scholarship", joined: "20 May 2026", status: "Active", apps: 0 },
  { id: 7, name: "Raj Kumar", email: "raj@example.com", role: "Student", joined: "4 Aug 2026", status: "Suspended", apps: 1 },
];

const ROLES = ["All", "Student", "Institution", "Scholarship", "Government", "Admin"];

export default function AdminUsers() {
  const [role, setRole] = useState("All");
  const [search, setSearch] = useState("");
  const filtered = USERS.filter(u =>
    (role === "All" || u.role === role) &&
    (u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">User Management</h1>
          <p className="text-slate-500 text-sm mt-0.5">{USERS.length} registered users</p>
        </div>
        <button className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white text-sm font-semibold rounded-xl transition-colors">+ Invite User</button>
      </div>

      <div className="flex gap-3 flex-wrap">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users…"
          className="flex-1 min-w-48 px-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl outline-none focus:border-purple-400 transition-colors" />
        <div className="flex gap-1 flex-wrap">
          {ROLES.map(r => (
            <button key={r} onClick={() => setRole(r)}
              className={`px-3 py-2 text-xs font-semibold rounded-xl transition-colors ${role === r ? "bg-purple-600 text-white" : "text-slate-500 bg-white border border-slate-200 hover:border-slate-300"}`}>{r}</button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {["User", "Email", "Role", "Joined", "Applications", "Status", "Actions"].map(h => (
                <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filtered.map(u => (
              <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-purple-700 text-white text-xs font-bold flex items-center justify-center shrink-0">
                      {u.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                    </div>
                    <p className="text-sm font-semibold text-slate-800">{u.name}</p>
                  </div>
                </td>
                <td className="px-4 py-4 text-xs text-slate-500">{u.email}</td>
                <td className="px-4 py-4">
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                    u.role === "Student" ? "bg-blue-50 text-blue-600" :
                    u.role === "Institution" ? "bg-teal-50 text-teal-700" :
                    u.role === "Government" ? "bg-green-50 text-green-700" :
                    u.role === "Scholarship" ? "bg-amber-50 text-amber-700" :
                    "bg-purple-50 text-purple-700"
                  }`}>{u.role}</span>
                </td>
                <td className="px-4 py-4 text-xs text-slate-500">{u.joined}</td>
                <td className="px-4 py-4 text-xs font-medium text-slate-600">{u.apps}</td>
                <td className="px-4 py-4"><Badge status={u.status} /></td>
                <td className="px-4 py-4">
                  <div className="flex gap-1.5">
                    <button className="text-xs text-purple-600 font-semibold hover:underline">Edit</button>
                    <span className="text-slate-200">|</span>
                    <button className="text-xs text-slate-400 hover:text-red-500">Suspend</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
