import { useState } from "react";
import { Badge } from "../../ui";

const INSTS = [
  { id: 1, name: "Universiti Malaya", short: "UM", type: "Public", location: "KL", programmes: 42, students: 28000, apps: 395, status: "Active", rating: 4.8 },
  { id: 2, name: "Universiti Teknologi Malaysia", short: "UTM", type: "Public", location: "Johor", programmes: 38, students: 24000, apps: 280, status: "Active", rating: 4.7 },
  { id: 3, name: "Universiti Putra Malaysia", short: "UPM", type: "Public", location: "Serdang", programmes: 35, students: 22000, apps: 245, status: "Active", rating: 4.6 },
  { id: 4, name: "Multimedia University", short: "MMU", type: "Private", location: "Cyberjaya", programmes: 28, students: 15000, apps: 180, status: "Active", rating: 4.4 },
  { id: 5, name: "Taylor's University", short: "TU", type: "Private", location: "Subang", programmes: 24, students: 12000, apps: 160, status: "Active", rating: 4.5 },
  { id: 6, name: "HELP University", short: "HELP", type: "Private", location: "KL", programmes: 18, students: 8000, apps: 95, status: "Pending", rating: 4.1 },
];

export default function AdminInstitutions() {
  const [type, setType] = useState("All");
  const [search, setSearch] = useState("");
  const filtered = INSTS.filter(i =>
    (type === "All" || i.type === type) &&
    i.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Institutions</h1>
          <p className="text-slate-500 text-sm mt-0.5">{INSTS.length} registered institutions</p>
        </div>
        <button className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white text-sm font-semibold rounded-xl transition-colors">+ Add Institution</button>
      </div>

      <div className="flex gap-3 flex-wrap">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search institutions…"
          className="flex-1 min-w-48 px-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl outline-none focus:border-purple-400 transition-colors" />
        {["All", "Public", "Private"].map(t => (
          <button key={t} onClick={() => setType(t)}
            className={`px-4 py-2.5 text-sm font-semibold rounded-xl transition-colors ${type === t ? "bg-purple-600 text-white" : "text-slate-500 bg-white border border-slate-200 hover:border-slate-300"}`}>{t}</button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(inst => (
          <div key={inst.id} className="bg-white rounded-2xl border border-slate-200 p-5 hover:border-purple-200 hover:shadow-sm transition-all">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center justify-center shrink-0">{inst.short}</div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">{inst.name}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{inst.type} · {inst.location}</p>
                </div>
              </div>
              <Badge status={inst.status} />
            </div>
            <div className="grid grid-cols-3 gap-2 mt-3">
              {[["Programmes", inst.programmes], ["Students", `${(inst.students / 1000).toFixed(0)}k`], ["Apps", inst.apps]].map(([l, v]) => (
                <div key={l as string} className="text-center bg-slate-50 rounded-xl p-2">
                  <p className="text-sm font-bold text-slate-800">{v}</p>
                  <p className="text-[9px] text-slate-400 mt-0.5 uppercase tracking-wide">{l as string}</p>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100">
              <div className="flex items-center gap-1">
                <span className="text-amber-400 text-sm">★</span>
                <span className="text-xs font-bold text-slate-700">{inst.rating}</span>
              </div>
              <div className="flex gap-2">
                <button className="text-xs text-purple-600 font-semibold hover:underline">Manage</button>
                <button className="text-xs text-slate-400 hover:text-slate-600">Analytics</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
