import { adminStats } from "../../data/mock";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

const userGrowth = [
  { month: "Mar", students: 8200, institutions: 42 }, { month: "Apr", students: 9800, institutions: 45 },
  { month: "May", students: 11200, institutions: 49 }, { month: "Jun", students: 13100, institutions: 52 },
  { month: "Jul", students: 14800, institutions: 55 }, { month: "Aug", students: adminStats.students, institutions: 60 },
];

const AGENTS = [
  { name: "Course Matcher", status: "Running", processed: "12,480 matches/hr", uptime: "99.9%" },
  { name: "Scholarship Finder", status: "Running", processed: "4,200 checks/hr", uptime: "99.7%" },
  { name: "Document Verifier", status: "Running", processed: "820 docs/hr", uptime: "98.5%" },
  { name: "Recommendation Engine", status: "Running", processed: "3,100 recs/hr", uptime: "99.8%" },
  { name: "Fraud Detector", status: "Idle", processed: "0/hr", uptime: "100%" },
];

const HEALTH = [
  { system: "API Gateway", status: "Operational", latency: "42ms" },
  { system: "Database Cluster", status: "Operational", latency: "8ms" },
  { system: "Search Engine", status: "Operational", latency: "91ms" },
  { system: "ML Pipeline", status: "Degraded", latency: "380ms" },
  { system: "Email Service", status: "Operational", latency: "120ms" },
  { system: "File Storage", status: "Operational", latency: "15ms" },
];

export default function AdminDashboard() {
  return (
    <div className="p-6 space-y-5 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">System Overview</h1>
          <p className="text-slate-500 text-sm mt-0.5">Edvora Platform · August 2026</p>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-green-600 font-semibold text-xs">All systems operational</span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { l: "Total Students", v: adminStats.students.toLocaleString(), c: "text-blue-600" },
          { l: "Institutions", v: adminStats.institutions.toLocaleString(), c: "text-teal-600" },
          { l: "Active Applications", v: adminStats.applications.toLocaleString(), c: "text-purple-600" },
          { l: "Active Users", v: adminStats.activeUsers.toLocaleString(), c: "text-amber-600" },
        ].map(s => (
          <div key={s.l} className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{s.l}</p>
            <p className={`text-2xl font-bold mt-2 ${s.c}`}>{s.v}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-4">Platform User Growth</p>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={userGrowth}>
            <defs>
              <linearGradient id="purpleGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#7C3AED" stopOpacity={0.12} />
                <stop offset="95%" stopColor="#7C3AED" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
            <Area type="monotone" dataKey="students" stroke="#7C3AED" strokeWidth={2.5} fill="url(#purpleGrad)" name="Students" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-4">AI Agent Status</p>
          <div className="space-y-3">
            {AGENTS.map(a => (
              <div key={a.name} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-2.5">
                  <span className={`w-2 h-2 rounded-full shrink-0 ${a.status === "Running" ? "bg-green-400" : "bg-slate-300"}`} />
                  <div>
                    <p className="text-xs font-semibold text-slate-700">{a.name}</p>
                    <p className="text-[10px] text-slate-400">{a.processed}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-[10px] font-bold ${a.status === "Running" ? "text-green-600" : "text-slate-400"}`}>{a.status}</p>
                  <p className="text-[10px] text-slate-400">{a.uptime} uptime</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-4">System Health</p>
          <div className="space-y-3">
            {HEALTH.map(h => (
              <div key={h.system} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${h.status === "Operational" ? "bg-green-400" : "bg-amber-400"}`} />
                  <p className="text-xs text-slate-700 font-medium">{h.system}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] text-slate-400">{h.latency}</span>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${h.status === "Operational" ? "bg-green-50 text-green-600" : "bg-amber-50 text-amber-600"}`}>{h.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
