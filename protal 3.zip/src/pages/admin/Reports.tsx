import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell } from "recharts";

const monthlyApps = [
  { month: "Mar", apps: 42000 }, { month: "Apr", apps: 58000 }, { month: "May", apps: 74000 },
  { month: "Jun", apps: 91000 }, { month: "Jul", apps: 88000 }, { month: "Aug", apps: 105000 },
];

const portalData = [
  { name: "Student", value: 1250000, color: "#2563EB" },
  { name: "Institution", value: 4250, color: "#0D9488" },
  { name: "Scholarship", value: 12500, color: "#D97706" },
  { name: "Government", value: 320, color: "#7C3AED" },
];

const scholarshipBreakdown = [
  { type: "Fully Funded", count: 3200, color: "#16A34A" },
  { type: "Partial Funding", count: 5800, color: "#2563EB" },
  { type: "Bursary", count: 3500, color: "#D97706" },
];

export default function AdminReports() {
  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Reports & Analytics</h1>
          <p className="text-slate-500 text-sm mt-0.5">Platform-wide statistics · August 2026</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 text-xs font-semibold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors">Export PDF</button>
          <button className="px-4 py-2 text-xs font-semibold text-purple-600 bg-purple-50 hover:bg-purple-100 rounded-xl transition-colors">Export CSV</button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { l: "Total Matches Made", v: "148.2M", d: "+18% MoM", c: "text-blue-600" },
          { l: "Scholarships Awarded", v: "86,400", d: "+22% YoY", c: "text-green-600" },
          { l: "Avg Session Time", v: "14m 32s", d: "+1m 8s vs last month", c: "text-purple-600" },
          { l: "Platform NPS", v: "72", d: "+4 points", c: "text-amber-600" },
        ].map(s => (
          <div key={s.l} className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{s.l}</p>
            <p className={`text-2xl font-bold mt-2 ${s.c}`}>{s.v}</p>
            <p className="text-[11px] text-green-500 font-semibold mt-1">{s.d}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-4">Monthly Applications Submitted</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyApps}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} tickFormatter={v => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} formatter={(v) => [(v as number).toLocaleString(), "Applications"]} />
              <Bar dataKey="apps" fill="#7C3AED" radius={[4, 4, 0, 0]} name="Applications" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-semibold text-slate-700 mb-4">User Distribution by Portal</p>
          <div className="flex items-center gap-6">
            <ResponsiveContainer width={160} height={160}>
              <PieChart>
                <Pie data={portalData} cx="50%" cy="50%" innerRadius={48} outerRadius={72} paddingAngle={3} dataKey="value">
                  {portalData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-2.5">
              {portalData.map(d => (
                <div key={d.name} className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: d.color }} />
                  <span className="text-xs text-slate-600 flex-1">{d.name}</span>
                  <span className="text-xs font-bold text-slate-800">{d.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-4">Scholarship Awards Breakdown</p>
        <div className="grid grid-cols-3 gap-4">
          {scholarshipBreakdown.map(s => (
            <div key={s.type} className="text-center p-4 bg-slate-50 rounded-xl">
              <div className="w-12 h-12 rounded-full mx-auto flex items-center justify-center mb-2" style={{ background: s.color + "20" }}>
                <span className="text-xl font-bold" style={{ color: s.color }}>{s.count >= 1000 ? `${(s.count / 1000).toFixed(1)}k` : s.count}</span>
              </div>
              <p className="text-xs font-semibold text-slate-600">{s.type}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100">
          <p className="text-sm font-semibold text-slate-700">Top Institutions by Applications</p>
        </div>
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50">
              {["Institution", "Applications", "Acceptance Rate", "Avg Match", "Enrolled"].map(h => (
                <th key={h} className="px-4 py-3 text-left text-[11px] font-semibold text-slate-400 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {[
              ["Universiti Malaya", "1,248", "32%", "91%", "320"],
              ["UTM", "986", "28%", "87%", "210"],
              ["UPM", "842", "35%", "84%", "195"],
              ["Multimedia University", "624", "42%", "82%", "180"],
              ["Taylor's University", "512", "38%", "79%", "148"],
            ].map(([name, apps, acc, match, enroll]) => (
              <tr key={name} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-3 text-sm font-semibold text-slate-800">{name}</td>
                <td className="px-4 py-3 text-sm text-slate-600">{apps}</td>
                <td className="px-4 py-3 text-sm text-slate-600">{acc}</td>
                <td className="px-4 py-3 text-sm font-semibold text-green-600">{match}</td>
                <td className="px-4 py-3 text-sm text-slate-600">{enroll}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
