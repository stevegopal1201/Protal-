import { useState } from "react";

const INTEGRATIONS = [
  { id: 1, name: "MyResults API", provider: "Lembaga Peperiksaan Malaysia", category: "Education", status: "Connected", lastSync: "2 min ago", color: "#2563EB" },
  { id: 2, name: "SPM Verification", provider: "Ministry of Education", category: "Education", status: "Connected", lastSync: "5 min ago", color: "#16A34A" },
  { id: 3, name: "PTPTN API", provider: "Perbadanan Tabung Pendidikan Tinggi", category: "Finance", status: "Connected", lastSync: "1 hr ago", color: "#0D9488" },
  { id: 4, name: "MySejahtera", provider: "Ministry of Health", category: "Government", status: "Connected", lastSync: "30 min ago", color: "#7C3AED" },
  { id: 5, name: "PayNet Gateway", provider: "PayNet Malaysia", category: "Finance", status: "Error", lastSync: "3 hrs ago", color: "#EF4444" },
  { id: 6, name: "JPA Scholarship DB", provider: "Jabatan Perkhidmatan Awam", category: "Finance", status: "Pending", lastSync: "Never", color: "#D97706" },
  { id: 7, name: "Stripe Payments", provider: "Stripe Inc.", category: "Finance", status: "Connected", lastSync: "Live", color: "#6366F1" },
  { id: 8, name: "SendGrid Email", provider: "Twilio SendGrid", category: "Communication", status: "Connected", lastSync: "Live", color: "#0EA5E9" },
];

const CATS = ["All", "Education", "Finance", "Government", "Communication"];

export default function AdminIntegrations() {
  const [cat, setCat] = useState("All");
  const filtered = INTEGRATIONS.filter(i => cat === "All" || i.category === cat);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Integrations</h1>
          <p className="text-slate-500 text-sm mt-0.5">{INTEGRATIONS.filter(i => i.status === "Connected").length} of {INTEGRATIONS.length} connected</p>
        </div>
        <button className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white text-sm font-semibold rounded-xl transition-colors">+ New Integration</button>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {CATS.map(c => (
          <button key={c} onClick={() => setCat(c)}
            className={`px-3 py-2 text-xs font-semibold rounded-xl transition-colors ${cat === c ? "bg-purple-600 text-white" : "text-slate-500 bg-white border border-slate-200 hover:border-slate-300"}`}>{c}</button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(int => (
          <div key={int.id} className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center gap-4 hover:border-slate-300 hover:shadow-sm transition-all">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white text-lg font-bold shrink-0"
              style={{ backgroundColor: int.color }}>
              {int.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-800">{int.name}</p>
              <p className="text-xs text-slate-400 mt-0.5 truncate">{int.provider}</p>
              <p className="text-[10px] text-slate-300 mt-1">Last sync: {int.lastSync}</p>
            </div>
            <div className="shrink-0 text-right">
              <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                int.status === "Connected" ? "bg-green-50 text-green-600" :
                int.status === "Error" ? "bg-red-50 text-red-600" :
                "bg-amber-50 text-amber-600"
              }`}>{int.status}</span>
              <div className="mt-2">
                <button className="text-xs text-purple-600 font-semibold hover:underline">Configure</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
