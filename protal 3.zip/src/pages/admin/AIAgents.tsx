import { useState } from "react";

const AGENTS = [
  { id: 1, name: "Course Matcher", desc: "Matches students to eligible courses using ML scoring", status: "Running", version: "v2.4.1", processed: "12,480/hr", accuracy: 94, uptime: "99.9%" },
  { id: 2, name: "Scholarship Finder", desc: "Identifies matching scholarship opportunities per profile", status: "Running", version: "v1.8.0", processed: "4,200/hr", accuracy: 91, uptime: "99.7%" },
  { id: 3, name: "Document Verifier", desc: "OCR + validation of uploaded academic documents", status: "Running", version: "v3.1.2", processed: "820/hr", accuracy: 97, uptime: "98.5%" },
  { id: 4, name: "Recommendation Engine", desc: "Personalized course recommendations via collaborative filtering", status: "Running", version: "v2.0.0", processed: "3,100/hr", accuracy: 89, uptime: "99.8%" },
  { id: 5, name: "Fraud Detector", desc: "Detects anomalous application and document patterns", status: "Idle", version: "v1.2.3", processed: "0/hr", accuracy: 98, uptime: "100%" },
  { id: 6, name: "Chatbot Advisor", desc: "Conversational AI advisor for student queries", status: "Running", version: "v4.0.0", processed: "1,900/hr", accuracy: 87, uptime: "99.5%" },
];

export default function AIAgents() {
  const [sel, setSel] = useState<number | null>(null);
  const agent = AGENTS.find(a => a.id === sel);

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">AI Agents</h1>
        <p className="text-slate-500 text-sm mt-0.5">{AGENTS.filter(a => a.status === "Running").length} agents running</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 space-y-3">
          {AGENTS.map(a => (
            <div key={a.id} onClick={() => setSel(sel === a.id ? null : a.id)}
              className={`bg-white rounded-2xl border p-5 cursor-pointer transition-all hover:shadow-sm ${sel === a.id ? "border-purple-400 shadow-sm" : "border-slate-200"}`}>
              <div className="flex items-start gap-3 justify-between">
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0 ${a.status === "Running" ? "bg-green-50" : "bg-slate-100"}`}>
                    🤖
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{a.name}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{a.desc}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${a.status === "Running" ? "bg-green-50 text-green-600" : "bg-slate-100 text-slate-500"}`}>
                    {a.status}
                  </span>
                  <span className="text-xs text-slate-300 font-mono">{a.version}</span>
                </div>
              </div>
              <div className="flex gap-5 mt-3 pt-3 border-t border-slate-100">
                {[["Throughput", a.processed], ["Accuracy", `${a.accuracy}%`], ["Uptime", a.uptime]].map(([l, v]) => (
                  <div key={l as string}>
                    <p className="text-[9px] text-slate-400 uppercase tracking-wide font-semibold">{l as string}</p>
                    <p className="text-xs font-bold text-slate-700 mt-0.5">{v as string}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="space-y-4">
          {agent ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-slate-800">{agent.name}</p>
                <button onClick={() => setSel(null)} className="text-xs text-slate-400 hover:text-slate-600">✕</button>
              </div>
              <div className="space-y-2">
                {[["Status", agent.status], ["Version", agent.version], ["Throughput", agent.processed], ["Accuracy", `${agent.accuracy}%`], ["Uptime", agent.uptime]].map(([l, v]) => (
                  <div key={l} className="flex justify-between py-2 border-b border-slate-50 last:border-0">
                    <span className="text-xs text-slate-400 font-medium">{l}</span>
                    <span className="text-xs font-semibold text-slate-700">{v}</span>
                  </div>
                ))}
              </div>
              <div className="flex flex-col gap-2">
                {agent.status === "Running"
                  ? <button className="w-full py-2 text-xs font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-xl transition-colors">Pause Agent</button>
                  : <button className="w-full py-2 text-xs font-semibold text-green-700 bg-green-50 hover:bg-green-100 rounded-xl transition-colors">Start Agent</button>
                }
                <button className="w-full py-2 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-xl transition-colors">View Logs</button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col items-center justify-center min-h-40 text-center">
              <p className="text-3xl mb-2">🤖</p>
              <p className="text-sm font-semibold text-slate-700">Select an agent</p>
              <p className="text-xs text-slate-400 mt-1">Click any agent to view details and controls</p>
            </div>
          )}

          <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-2xl p-5 text-white">
            <p className="text-sm font-semibold">System Performance</p>
            <div className="mt-3 space-y-2">
              {[["Total Matches Today", "148,000"], ["Scholarships Found", "32,400"], ["Docs Verified", "6,800"]].map(([l, v]) => (
                <div key={l} className="flex justify-between">
                  <span className="text-purple-200 text-xs">{l}</span>
                  <span className="text-white text-xs font-bold">{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
