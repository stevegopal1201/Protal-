import { useState } from "react";
import { student } from "../../data/mock";
import { ProgressBar } from "../../ui";

const TABS = ["Overview", "Academic", "Preferences", "Security"];

export default function StudentProfile() {
  const [tab, setTab] = useState("Overview");
  const [editing, setEditing] = useState(false);

  const completionColor = student.completion >= 90 ? "#16A34A" : student.completion >= 70 ? "#2563EB" : "#D97706";
  const circ = 2 * Math.PI * 28;
  const dash = (student.completion / 100) * circ;

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-5">
      {/* Hero card */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="h-24 w-full" style={{ background: "linear-gradient(135deg, #0B1F3A 0%, #1e3a5f 60%, #1d4ed8 100%)" }} />
        <div className="px-6 pb-5">
          <div className="flex items-end justify-between -mt-10 mb-4">
            <div className="w-20 h-20 rounded-2xl bg-blue-600 border-4 border-white flex items-center justify-center text-white text-3xl font-bold shadow-lg shrink-0">
              {student.name.charAt(0)}
            </div>
            <button
              onClick={() => setEditing(!editing)}
              className={`px-4 py-2 text-sm font-semibold rounded-xl transition-colors ${editing ? "bg-blue-600 text-white" : "border border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
              {editing ? "Save Changes" : "Edit Profile"}
            </button>
          </div>
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900">{student.name}</h2>
              <p className="text-sm text-slate-400 mt-0.5">{student.email}</p>
              <div className="flex flex-wrap gap-2 mt-3">
                <span className="px-2.5 py-1 bg-blue-50 text-blue-700 text-xs font-semibold rounded-full">Student</span>
                <span className="px-2.5 py-1 bg-slate-100 text-slate-600 text-xs font-semibold rounded-full">{student.nationality}</span>
                <span className="px-2.5 py-1 bg-green-50 text-green-700 text-xs font-semibold rounded-full">✓ Verified</span>
              </div>
            </div>
            <div className="shrink-0 flex flex-col items-center gap-1">
              <div className="relative w-16 h-16 flex items-center justify-center">
                <svg width="64" height="64" style={{ transform: "rotate(-90deg)", position: "absolute", top: 0, left: 0 }}>
                  <circle cx="32" cy="32" r="28" fill="none" stroke="#E2E8F0" strokeWidth="6" />
                  <circle cx="32" cy="32" r="28" fill="none" stroke={completionColor} strokeWidth="6"
                    strokeLinecap="round" strokeDasharray={`${dash} ${circ - dash}`} />
                </svg>
                <span className="text-base font-bold" style={{ color: completionColor }}>{student.completion}%</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Profile Complete</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-white border border-slate-200 p-1 rounded-xl w-fit">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${tab === t ? "bg-blue-600 text-white shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === "Overview" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 space-y-5">
            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <p className="text-sm font-semibold text-slate-700 mb-4">Personal Information</p>
              <div className="grid grid-cols-2 gap-3">
                {[
                  ["Full Name", student.name],
                  ["Nationality", student.nationality],
                  ["Email Address", student.email],
                  ["Mobile", "+60 12 345 6789"],
                  ["Date of Birth", "15 Jan 2007"],
                  ["IC Number", "070115-14-XXXX"],
                  ["State", "Selangor"],
                  ["City", "Petaling Jaya"],
                ].map(([label, value]) => (
                  <div key={label} className="bg-slate-50 rounded-xl p-3">
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wide">{label}</p>
                    {editing ? (
                      <input defaultValue={value} className="w-full text-sm font-medium text-slate-700 bg-transparent border-b border-blue-300 outline-none mt-1" />
                    ) : (
                      <p className="text-sm font-medium text-slate-700 mt-0.5 truncate">{value}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <p className="text-sm font-semibold text-slate-700 mb-4">Education Background</p>
              <div className="grid grid-cols-2 gap-3">
                {[
                  ["Qualification", "SPM (2025)"],
                  ["School", "SMK Petaling Jaya"],
                  ["Current Status", "SPM Graduate"],
                  ["Intake Target", "March / Sept 2027"],
                ].map(([label, value]) => (
                  <div key={label} className="bg-slate-50 rounded-xl p-3">
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wide">{label}</p>
                    <p className="text-sm font-medium text-slate-700 mt-0.5">{value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-5">
            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <p className="text-sm font-semibold text-slate-700 mb-3">Profile Completion</p>
              <div className="space-y-2.5">
                {[
                  ["Personal Info", 100, true],
                  ["Academic Results", 100, true],
                  ["Career Goals", 80, true],
                  ["Documents", 83, true],
                  ["Preferences", 60, false],
                  ["Parent Info", 40, false],
                ].map(([label, pct, done]) => (
                  <div key={label as string}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className={`font-medium ${done ? "text-slate-600" : "text-slate-400"}`}>{label as string}</span>
                      <span className={`font-bold ${done ? "text-slate-700" : "text-slate-400"}`}>{pct as number}%</span>
                    </div>
                    <ProgressBar value={pct as number} color={done ? "#16A34A" : "#94A3B8"} />
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-5 text-white">
              <p className="text-sm font-semibold mb-1">AI Profile Score</p>
              <p className="text-3xl font-bold">8.4 / 10</p>
              <p className="text-blue-200 text-xs mt-2 leading-relaxed">Your profile is strong. Add parent income details and a personal statement to reach 10/10.</p>
              <button className="mt-3 text-xs font-semibold text-blue-100 underline">Complete Now →</button>
            </div>
          </div>
        </div>
      )}

      {tab === "Academic" && (
        <div className="space-y-5">
          <div className="grid grid-cols-3 gap-4">
            {[
              ["GPA", (student.subjects.reduce((s, x) => s + x.score, 0) / student.subjects.length / 20).toFixed(2), "out of 5.0"],
              ["Subjects", student.subjects.length.toString(), "completed"],
              ["A Grades", student.subjects.filter(s => s.grade === "A").length.toString(), "subjects"],
            ].map(([l, v, s]) => (
              <div key={l} className="bg-white rounded-2xl border border-slate-200 p-5 text-center">
                <p className="text-3xl font-bold text-slate-900">{v}</p>
                <p className="text-xs text-slate-400 mt-1">{s}</p>
                <p className="text-xs font-semibold text-slate-600 mt-0.5">{l}</p>
              </div>
            ))}
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex justify-between items-center">
              <p className="text-sm font-semibold text-slate-700">SPM Results</p>
              <span className="text-xs font-semibold text-green-600 bg-green-50 px-2.5 py-1 rounded-full">✓ Verified</span>
            </div>
            <div className="divide-y divide-slate-50">
              {student.subjects.map((s, i) => (
                <div key={i} className="flex items-center gap-4 px-5 py-4 hover:bg-slate-50 transition-colors">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold shrink-0 ${
                    s.grade === "A" ? "bg-green-50 text-green-700" :
                    s.grade === "B" ? "bg-blue-50 text-blue-700" :
                    "bg-amber-50 text-amber-700"
                  }`}>{s.grade}</div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-800">{s.subject}</p>
                    <div className="mt-1.5">
                      <ProgressBar value={s.score}
                        color={s.grade === "A" ? "#16A34A" : s.grade === "B" ? "#2563EB" : "#D97706"} />
                    </div>
                  </div>
                  <div className="text-right shrink-0 w-16">
                    <p className="text-sm font-bold text-slate-800">{s.score}%</p>
                    {s.verified && <p className="text-[10px] text-green-500 font-semibold mt-0.5">Verified</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === "Preferences" && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-5 max-w-2xl">
          <p className="text-sm font-semibold text-slate-700">Study Preferences</p>
          <div className="space-y-4">
            {[
              { label: "Preferred Study Mode", opts: ["Full-time", "Part-time", "Online", "Hybrid"], sel: "Full-time" },
              { label: "Preferred Location", opts: ["Kuala Lumpur", "Selangor", "Johor", "Any"], sel: "Kuala Lumpur" },
              { label: "Budget Range", opts: ["< RM 15k/yr", "RM 15–25k/yr", "RM 25–40k/yr", "> RM 40k/yr"], sel: "RM 15–25k/yr" },
            ].map(pref => (
              <div key={pref.label}>
                <p className="text-xs font-semibold text-slate-500 mb-2">{pref.label}</p>
                <div className="flex gap-2 flex-wrap">
                  {pref.opts.map(o => (
                    <button key={o} className={`px-3 py-2 text-xs font-semibold rounded-xl border transition-colors ${o === pref.sel ? "border-blue-600 bg-blue-50 text-blue-700" : "border-slate-200 text-slate-500 hover:border-slate-300"}`}>{o}</button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <button className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-colors">Save Preferences</button>
        </div>
      )}

      {tab === "Security" && (
        <div className="max-w-2xl space-y-4">
          {[
            { label: "Change Password", desc: "Last changed 30 days ago", action: "Update" },
            { label: "Two-Factor Authentication", desc: "Not enabled — adds extra security", action: "Enable" },
            { label: "Login Sessions", desc: "2 active sessions", action: "Manage" },
            { label: "Delete Account", desc: "Permanently remove your account and data", action: "Delete", danger: true },
          ].map(item => (
            <div key={item.label} className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-800">{item.label}</p>
                <p className="text-xs text-slate-400 mt-0.5">{item.desc}</p>
              </div>
              <button className={`px-4 py-2 text-xs font-semibold rounded-xl transition-colors ${item.danger ? "text-red-600 bg-red-50 hover:bg-red-100" : "text-blue-600 bg-blue-50 hover:bg-blue-100"}`}>
                {item.action}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
