import { useState } from "react";
import { useParams, useNavigate } from "react-router";
import { courses } from "../../data/mock";
import { MatchRing, Badge } from "../../ui";

const TABS = ["Overview", "Requirements", "Fees", "Career", "Intake", "Scholarships"];

export default function CourseDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tab, setTab] = useState("Overview");
  const c = courses.find(x => x.id === Number(id)) ?? courses[0];
  const total = Object.values(c.fees).reduce((a, b) => a + b, 0);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-5">
      <button onClick={() => navigate(-1)} className="text-sm text-slate-500 hover:text-slate-700 font-medium flex items-center gap-1">← Back</button>

      {/* Hero */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <div className="flex items-start gap-5">
          <div className="w-16 h-16 rounded-2xl bg-slate-900 text-white text-sm font-bold flex items-center justify-center shrink-0">{c.logo}</div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-slate-400">{c.institution} · {c.location}</p>
            <h1 className="text-xl font-bold text-slate-900 mt-0.5">{c.name}</h1>
            <div className="flex flex-wrap gap-2 mt-3">
              <Badge status={c.eligible ? "Eligible" : "Conditional"} />
              {c.scholarship && <span className="px-2.5 py-1 bg-purple-50 text-purple-700 text-xs font-semibold rounded-full">🎓 Scholarship Available</span>}
              <span className="px-2.5 py-1 bg-slate-100 text-slate-600 text-xs font-semibold rounded-full">{c.mode}</span>
            </div>
          </div>
          <div className="shrink-0 flex flex-col items-center">
            <MatchRing score={c.match} size={72} />
            <p className="text-[10px] text-slate-400 mt-1">Match Score</p>
          </div>
        </div>
        <div className="grid grid-cols-4 gap-3 mt-5 pt-5 border-t border-slate-100 text-center">
          {[["Tuition/Year", c.tuition], ["Duration", c.duration], ["Location", c.location], ["Accreditation", "MQA"]].map(([l, v]) => (
            <div key={l}><p className="text-sm font-semibold text-slate-800">{v}</p><p className="text-xs text-slate-400 mt-0.5">{l}</p></div>
          ))}
        </div>
        <div className="flex gap-3 mt-5">
          <button onClick={() => navigate("/student/applications")} className="flex-1 max-w-xs bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 rounded-xl text-sm transition-colors">Apply Now</button>
          <button className="px-5 py-2.5 border border-slate-200 hover:border-slate-300 text-slate-600 font-semibold text-sm rounded-xl transition-colors">Save</button>
          <button onClick={() => navigate("/student/compare")} className="px-5 py-2.5 border border-slate-200 hover:border-slate-300 text-slate-600 font-semibold text-sm rounded-xl transition-colors">Compare</button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex overflow-x-auto border-b border-slate-200">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-5 py-3 text-sm font-semibold whitespace-nowrap border-b-2 transition-colors ${tab === t ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500 hover:text-slate-700"}`}>
            {t}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        {tab === "Overview" && (
          <div className="space-y-4">
            <p className="text-sm text-slate-600 leading-relaxed">{c.description}</p>
            <div className="grid grid-cols-2 gap-3">
              {[["Faculty", c.faculty], ["Mode", c.mode], ["Duration", c.duration], ["Accreditation", "MQA Accredited"]].map(([l, v]) => (
                <div key={l} className="bg-slate-50 rounded-xl p-4">
                  <p className="text-xs text-slate-400">{l}</p>
                  <p className="text-sm font-semibold text-slate-700 mt-1">{v}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "Requirements" && (
          <div className="space-y-4">
            <p className="text-sm font-semibold text-slate-700">Your Eligibility Check</p>
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>{["Subject", "Required", "Your Result", "Status"].map(h => <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-slate-500">{h}</th>)}</tr>
                </thead>
                <tbody>
                  {c.requirements.map((r, i) => (
                    <tr key={i} className="border-b border-slate-100 last:border-0 hover:bg-slate-50">
                      <td className="px-4 py-3 text-sm font-medium text-slate-700">{r.subject}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{r.required}</td>
                      <td className="px-4 py-3 text-sm font-semibold text-slate-800">{r.yours}</td>
                      <td className="px-4 py-3 text-sm">{r.met ? <span className="text-green-600">✓ Met</span> : <span className="text-red-500">✗ Not Met</span>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {c.requirements.every(r => r.met) && (
              <div className="bg-green-50 border border-green-100 rounded-xl p-4 flex items-center gap-3">
                <span className="text-2xl">✅</span>
                <div>
                  <p className="text-sm font-semibold text-green-800">You meet all requirements</p>
                  <p className="text-xs text-green-600 mt-0.5">Your academic results qualify you for this programme</p>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === "Fees" && (
          <div className="space-y-4">
            {Object.entries(c.fees).map(([key, val]) => (
              <div key={key} className="flex items-center gap-4">
                <span className="w-32 text-sm text-slate-600 capitalize shrink-0">{key}</span>
                <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: `${(val / total) * 100}%` }} />
                </div>
                <span className="w-28 text-right text-sm font-semibold text-slate-700 shrink-0">RM {val.toLocaleString()}</span>
              </div>
            ))}
            <div className="border-t border-slate-200 pt-4 flex justify-between">
              <span className="text-sm font-bold text-slate-800">Estimated Total / Year</span>
              <span className="text-base font-bold text-slate-900">RM {total.toLocaleString()}</span>
            </div>
          </div>
        )}

        {tab === "Career" && (
          <div className="grid grid-cols-2 gap-3">
            {c.careers.map(career => (
              <div key={career} className="flex items-center gap-3 bg-slate-50 rounded-xl p-3.5">
                <span className="text-lg">💼</span>
                <span className="text-sm font-medium text-slate-700">{career}</span>
              </div>
            ))}
          </div>
        )}

        {tab === "Intake" && (
          <div className="space-y-3">
            {c.intakes.map(intake => (
              <div key={intake} className="flex items-center justify-between bg-slate-50 rounded-xl p-4">
                <div>
                  <p className="text-sm font-semibold text-slate-800">{intake}</p>
                  <p className="text-xs text-slate-400 mt-0.5">Application opens 3 months prior</p>
                </div>
                <Badge status="Published" />
              </div>
            ))}
          </div>
        )}

        {tab === "Scholarships" && (
          <div className="space-y-3">
            {c.scholarship ? (
              <div className="bg-purple-50 border border-purple-100 rounded-xl p-4">
                <p className="text-sm font-semibold text-purple-800">Future Technology Scholarship</p>
                <p className="text-xs text-purple-600 mt-0.5">ABC Foundation · 96% Match · Fully Funded · Tuition 100%</p>
                <button onClick={() => navigate("/student/scholarships/1")} className="mt-2 text-xs text-blue-600 font-semibold hover:underline">View Details →</button>
              </div>
            ) : (
              <p className="text-sm text-slate-400 text-center py-6">No scholarships linked to this programme</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
