import { useState } from "react";
import { useNavigate } from "react-router";

const STEPS = ["Personal", "Education", "Results", "Interests", "Career", "Budget", "Preferences", "Complete"];

export default function StudentOnboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [interests, setInterests] = useState<string[]>(["Computer Science", "Technology"]);
  const allInterests = ["Computer Science", "Engineering", "Medicine", "Business", "Law", "Arts", "Science", "Education", "Architecture", "Technology"];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 p-6" style={{ fontFamily: "Inter, sans-serif" }}>
      <div className="w-full max-w-xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm">E</div>
            <span className="font-semibold text-slate-800">Edvora</span>
          </div>
          <span className="text-sm text-slate-400">Step {step + 1} of {STEPS.length}</span>
        </div>

        {/* Progress */}
        <div className="flex gap-1 mb-6">
          {STEPS.map((_, i) => (
            <div key={i} className={`flex-1 h-1.5 rounded-full transition-all ${i <= step ? "bg-blue-600" : "bg-slate-200"}`} />
          ))}
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-7">
          <h2 className="text-xl font-bold text-slate-800 mb-1">{
            ["Personal Information", "Education Background", "Examination Results", "Study Interests", "Career Goals", "Budget & Financial", "Preferences", "Profile Complete!"][step]
          }</h2>
          <p className="text-sm text-slate-400 mb-5">{
            ["Tell us about yourself", "Your secondary school background", "Enter your subject results", "Select fields you want to study", "What career are you aiming for?", "Help us find affordable options", "Customize your study experience", "We found matching courses and scholarships"][step]
          }</p>

          {step === 0 && (
            <div className="grid grid-cols-2 gap-4">
              {[["Full Name", "text", "Steve Lim", 2], ["Date of Birth", "date", "", 1], ["Nationality", "text", "Malaysian", 1], ["Country", "text", "Malaysia", 1], ["State", "text", "Selangor", 1], ["Email", "email", "steve@email.com", 2], ["Mobile", "tel", "+60 12 345 6789", 2]].map(([l, t, p, s]) => (
                <div key={l as string} className={s === 2 ? "col-span-2" : ""}>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5">{l as string}</label>
                  <input type={t as string} defaultValue={p as string} className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl outline-none focus:border-blue-400 transition-all" />
                </div>
              ))}
            </div>
          )}

          {step === 1 && (
            <div className="grid grid-cols-2 gap-4">
              {[["School Name", "SMK Petaling Jaya", 2], ["Country", "Malaysia", 1], ["Qualification", "SPM", 1], ["Exam Board", "Lembaga Peperiksaan Malaysia", 2], ["Year", "2024", 2]].map(([l, p, s]) => (
                <div key={l as string} className={s === 2 ? "col-span-2" : ""}>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5">{l as string}</label>
                  <input type="text" defaultValue={p as string} className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl outline-none focus:border-blue-400 transition-all" />
                </div>
              ))}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-3">
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-100">
                    <tr>
                      {["Subject", "Grade", "Score", ""].map(h => (
                        <th key={h} className="text-left px-4 py-2.5 text-xs font-semibold text-slate-500">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[["Mathematics", "A", "85"], ["English", "B", "72"], ["Physics", "A", "88"], ["Chemistry", "B", "76"], ["Biology", "C", "65"]].map(([s, g, sc]) => (
                      <tr key={s} className="border-b border-slate-50 last:border-0">
                        <td className="px-4 py-2.5 text-xs font-medium text-slate-700">{s}</td>
                        <td className="px-4 py-2.5"><span className={`text-xs font-bold ${g === "A" ? "text-green-600" : g === "B" ? "text-blue-600" : "text-amber-600"}`}>{g}</span></td>
                        <td className="px-4 py-2.5 text-xs text-slate-600">{sc}</td>
                        <td className="px-4 py-2.5 text-green-500 text-xs">✓</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="border-2 border-dashed border-slate-200 rounded-xl p-4 text-center hover:border-blue-300 transition-colors cursor-pointer">
                <p className="text-xs text-slate-500">📎 Upload Certificate · <span className="text-purple-600 font-medium">Extract with AI</span></p>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="flex flex-wrap gap-2">
              {allInterests.map(i => (
                <button key={i} onClick={() => setInterests(p => p.includes(i) ? p.filter(x => x !== i) : [...p, i])}
                  className={`px-4 py-2 rounded-full text-sm font-medium border-2 transition-all ${interests.includes(i) ? "border-blue-600 bg-blue-600 text-white" : "border-slate-200 text-slate-600 hover:border-slate-300"}`}>
                  {i}
                </button>
              ))}
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Dream Career</label>
                <input type="text" defaultValue="AI Engineer" className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl outline-none focus:border-blue-400 transition-all" />
              </div>
              <div className="bg-blue-50 rounded-xl p-4 space-y-3">
                <p className="text-xs font-semibold text-blue-800">AI-Suggested Pathway: AI Engineer</p>
                {[["Required Skills", ["Python", "Mathematics", "Machine Learning", "Cloud"]], ["Recommended Programmes", ["Computer Science", "AI", "Data Science"]], ["Top Institutions", ["Universiti Malaya", "APU", "UTM"]]].map(([title, items]) => (
                  <div key={title as string}>
                    <p className="text-[11px] text-blue-600 font-semibold mb-1">{title as string}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {(items as string[]).map(i => <span key={i} className="px-2 py-0.5 bg-white text-blue-700 text-[11px] font-medium rounded-full border border-blue-200">{i}</span>)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-2">Annual Tuition Budget</label>
                <input type="range" min="5000" max="80000" step="5000" defaultValue="30000" className="w-full accent-blue-600" />
                <div className="flex justify-between text-xs text-slate-400 mt-1"><span>RM 5,000</span><span className="text-blue-600 font-semibold">RM 30,000</span><span>RM 80,000+</span></div>
              </div>
              {[["Annual Family Income", ["Below RM 40,000", "RM 40,000–80,000", "RM 80,000–150,000", "Above RM 150,000"]], ["Scholarship Priority", ["High — Prioritize scholarships", "Medium", "Low"]]].map(([l, opts]) => (
                <div key={l as string}>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5">{l as string}</label>
                  <select className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl outline-none focus:border-blue-400 transition-all bg-white">
                    {(opts as string[]).map(o => <option key={o}>{o}</option>)}
                  </select>
                </div>
              ))}
            </div>
          )}

          {step === 6 && (
            <div className="space-y-4">
              {[["Preferred Country", ["Malaysia", "Singapore", "Australia", "UK", "Any"]], ["Study Mode", ["Full-time", "Part-time", "Online", "Any"]], ["Duration", ["3 Years", "4 Years", "Any"]]].map(([l, opts]) => (
                <div key={l as string}>
                  <label className="block text-xs font-semibold text-slate-600 mb-2">{l as string}</label>
                  <div className="flex flex-wrap gap-2">
                    {(opts as string[]).map((o, i) => (
                      <button key={o} className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${i === 0 ? "border-blue-600 bg-blue-600 text-white" : "border-slate-200 text-slate-600 hover:border-slate-300"}`}>{o}</button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {step === 7 && (
            <div className="text-center space-y-5 py-4">
              <div className="w-20 h-20 rounded-full bg-green-50 flex items-center justify-center text-4xl mx-auto">🎉</div>
              <p className="text-slate-500 text-sm">We found <strong className="text-blue-600">43 matching courses</strong> and <strong className="text-purple-600">12 scholarships</strong> for you.</p>
              <div className="grid grid-cols-3 gap-3">
                {[["94%", "Top Match", "bg-green-50 text-green-700"], ["96%", "Top Scholarship", "bg-purple-50 text-purple-700"], ["38", "Eligible Courses", "bg-blue-50 text-blue-700"]].map(([v, l, c]) => (
                  <div key={l} className={`rounded-xl p-3 ${c.split(" ").slice(0, 1)[0]}`}>
                    <p className={`text-xl font-bold ${c.split(" ")[1]}`}>{v}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{l}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Nav */}
        <div className="flex justify-between mt-5">
          <button onClick={() => step > 0 ? setStep(s => s - 1) : navigate("/")}
            className="px-5 py-2.5 text-sm font-semibold text-slate-600 border border-slate-200 bg-white hover:bg-slate-50 rounded-xl transition-colors">
            {step === 0 ? "← Back" : "← Previous"}
          </button>
          <button onClick={() => step < STEPS.length - 1 ? setStep(s => s + 1) : navigate("/student")}
            className="px-6 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors">
            {step === STEPS.length - 1 ? "Go to Dashboard →" : "Continue →"}
          </button>
        </div>
      </div>
    </div>
  );
}
