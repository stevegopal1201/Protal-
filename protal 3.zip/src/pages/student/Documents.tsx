import { useState } from "react";

const DOCS = [
  { id: 1, name: "Examination Certificate", type: "PDF", size: "1.2 MB", date: "10 Aug 2026", status: "verified" },
  { id: 2, name: "Academic Transcript", type: "PDF", size: "0.8 MB", date: "10 Aug 2026", status: "verified" },
  { id: 3, name: "Passport", type: "JPG", size: "0.5 MB", date: "11 Aug 2026", status: "verified" },
  { id: 4, name: "Personal Statement", type: "PDF", size: "", date: "", status: "missing" },
  { id: 5, name: "Recommendation Letter", type: "PDF", size: "0.3 MB", date: "12 Aug 2026", status: "verified" },
  { id: 6, name: "IC / Birth Certificate", type: "JPG", size: "0.4 MB", date: "10 Aug 2026", status: "pending" },
];

export default function Documents() {
  const [drag, setDrag] = useState(false);
  const verified = DOCS.filter(d => d.status === "verified").length;

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">My Documents</h1>
          <p className="text-slate-500 text-sm mt-1">{verified} of {DOCS.length} documents uploaded and verified</p>
        </div>
        <button className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-colors">+ Upload</button>
      </div>

      {/* Completion */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
        <div className="flex justify-between text-xs">
          <span className="text-slate-500 font-medium">Document Completion</span>
          <span className="font-bold text-slate-800">{Math.round((verified / DOCS.length) * 100)}%</span>
        </div>
        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-green-500 rounded-full transition-all" style={{ width: `${(verified / DOCS.length) * 100}%` }} />
        </div>
        <div className="flex gap-5 text-xs">
          {[["Verified", "text-green-600", DOCS.filter(d => d.status === "verified").length], ["Pending", "text-amber-600", DOCS.filter(d => d.status === "pending").length], ["Missing", "text-red-500", DOCS.filter(d => d.status === "missing").length]].map(([l, c, n]) => (
            <div key={l as string}><span className={`font-bold ${c as string}`}>{n as number}</span><span className="text-slate-400 ml-1">{l as string}</span></div>
          ))}
        </div>
      </div>

      {/* Drop zone */}
      <div
        onDragOver={e => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={e => { e.preventDefault(); setDrag(false); }}
        className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer ${drag ? "border-blue-400 bg-blue-50" : "border-slate-200 hover:border-blue-300 hover:bg-slate-50"}`}>
        <div className="text-3xl mb-2">📎</div>
        <p className="text-sm font-semibold text-slate-700">Drag and drop files here</p>
        <p className="text-xs text-slate-400 mt-1">PDF, JPG, PNG · Max 10 MB per file</p>
        <div className="flex justify-center gap-3 mt-4">
          <button className="px-4 py-2 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors">Browse Files</button>
          <button className="px-4 py-2 text-xs font-semibold text-purple-600 bg-purple-50 hover:bg-purple-100 rounded-xl transition-colors">🤖 Extract with AI</button>
        </div>
      </div>

      {/* List */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100">
          <p className="text-sm font-semibold text-slate-700">All Documents</p>
        </div>
        {DOCS.map(doc => (
          <div key={doc.id} className="flex items-center gap-4 px-5 py-4 border-b border-slate-50 last:border-0 hover:bg-slate-50 transition-colors">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg shrink-0 ${doc.status === "verified" ? "bg-green-50" : doc.status === "missing" ? "bg-red-50" : "bg-amber-50"}`}>
              {doc.status === "verified" ? "✅" : doc.status === "missing" ? "⚠️" : "⏳"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-800">{doc.name}</p>
              <p className={`text-xs mt-0.5 ${doc.status === "missing" ? "text-red-400" : "text-slate-400"}`}>
                {doc.size ? `${doc.type} · ${doc.size} · Uploaded ${doc.date}` : "Not yet uploaded"}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${doc.status === "verified" ? "bg-green-50 text-green-600" : doc.status === "pending" ? "bg-amber-50 text-amber-600" : "bg-red-50 text-red-600"}`}>
                {doc.status === "verified" ? "Verified" : doc.status === "pending" ? "Pending" : "Required"}
              </span>
              {doc.status !== "missing"
                ? <><button className="text-xs text-slate-400 hover:text-slate-600 px-2 py-1 hover:bg-slate-100 rounded transition-colors">Preview</button><button className="text-xs text-slate-400 hover:text-slate-600 px-2 py-1 hover:bg-slate-100 rounded transition-colors">Replace</button></>
                : <button className="text-xs text-blue-600 font-semibold px-3 py-1.5 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors">Upload</button>
              }
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
