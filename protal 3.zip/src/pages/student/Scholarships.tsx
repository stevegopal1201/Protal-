import { useState } from "react";
import { useNavigate } from "react-router";
import { scholarships } from "../../data/mock";
import { MatchRing, Badge } from "../../ui";

const FILTERS = {
  type: ["Any", "Fully Funded", "Partial Funding"],
  deadline: ["Any", "Urgent (< 15 days)", "Soon (< 45 days)", "Open (> 45 days)"],
};

export default function Scholarships() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("Any");
  const [deadlineFilter, setDeadlineFilter] = useState("Any");

  const filtered = scholarships.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.provider.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "Any" || s.type === typeFilter;
    const matchDeadline =
      deadlineFilter === "Any" ||
      (deadlineFilter === "Urgent (< 15 days)" && s.daysLeft < 15) ||
      (deadlineFilter === "Soon (< 45 days)" && s.daysLeft < 45) ||
      (deadlineFilter === "Open (> 45 days)" && s.daysLeft >= 45);
    return matchSearch && matchType && matchDeadline;
  });

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Scholarships</h1>
          <p className="text-slate-500 text-sm mt-1">{filtered.length} scholarships matching your profile · {scholarships.filter(s => s.type === "Fully Funded").length} fully funded</p>
        </div>
        <div className="flex gap-2">
          <span className="px-3 py-1.5 bg-amber-50 text-amber-700 text-xs font-semibold rounded-full border border-amber-200">⚠️ 1 deadline in &lt;7 days</span>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
        <div className="relative">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
          <input
            type="text"
            placeholder="Search scholarships or providers…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 text-sm border border-slate-200 rounded-xl outline-none focus:border-blue-400 transition-all"
          />
        </div>
        <div className="flex flex-wrap gap-4">
          <div className="space-y-1">
            <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wide">Funding Type</p>
            <div className="flex gap-1.5">
              {FILTERS.type.map(f => (
                <button key={f} onClick={() => setTypeFilter(f)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${typeFilter === f ? "bg-blue-600 text-white border-blue-600" : "border-slate-200 text-slate-500 hover:border-slate-300"}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wide">Deadline</p>
            <div className="flex gap-1.5 flex-wrap">
              {FILTERS.deadline.map(f => (
                <button key={f} onClick={() => setDeadlineFilter(f)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${deadlineFilter === f ? "bg-blue-600 text-white border-blue-600" : "border-slate-200 text-slate-500 hover:border-slate-300"}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Cards */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 bg-white rounded-2xl border border-slate-200">
          <p className="text-4xl mb-3">🎓</p>
          <p className="font-semibold text-slate-700">No scholarships match your filters</p>
          <button onClick={() => { setTypeFilter("Any"); setDeadlineFilter("Any"); setSearch(""); }} className="mt-3 text-sm text-blue-600 font-semibold hover:underline">Clear filters</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-2 gap-4">
          {filtered.map(s => {
            const urgent = s.daysLeft <= 14;
            const soon = s.daysLeft <= 45 && !urgent;
            return (
              <div key={s.id}
                className={`bg-white rounded-2xl border p-5 flex flex-col gap-4 hover:shadow-md transition-all cursor-pointer ${urgent ? "border-red-200 hover:border-red-300" : "border-slate-200 hover:border-slate-300"}`}
                onClick={() => navigate(`/student/scholarships/${s.id}`)}>
                {/* Header */}
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center text-white text-lg shrink-0">🎓</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-slate-800 leading-snug">{s.name}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{s.provider}</p>
                  </div>
                  <MatchRing score={s.match} size={52} />
                </div>

                {/* Type badge + deadline urgency */}
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge status={s.type} dot={false} />
                  {urgent && <span className="text-[10px] font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded-full border border-red-200">🔥 {s.daysLeft} days left</span>}
                  {soon && <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">⏳ {s.daysLeft} days left</span>}
                  {!urgent && !soon && <span className="text-[10px] font-semibold text-slate-400">{s.daysLeft} days left</span>}
                </div>

                {/* Details grid */}
                <div className="grid grid-cols-3 gap-2">
                  {[
                    ["Tuition", s.tuition, urgent ? "text-red-700 bg-red-50" : "text-blue-700 bg-blue-50"],
                    ["Living", s.living, "text-green-700 bg-green-50"],
                    ["Recipients", s.recipients.toString(), "text-purple-700 bg-purple-50"],
                  ].map(([k, v, cls]) => (
                    <div key={k as string} className={`rounded-xl p-2.5 text-center ${cls as string}`}>
                      <p className="text-[9px] font-semibold uppercase tracking-wide opacity-70">{k as string}</p>
                      <p className="text-xs font-bold mt-0.5">{v as string}</p>
                    </div>
                  ))}
                </div>

                {/* Eligible programmes */}
                <div className="flex flex-wrap gap-1.5">
                  {s.programmes.slice(0, 3).map(p => (
                    <span key={p} className="text-[10px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full font-medium">{p}</span>
                  ))}
                  {s.programmes.length > 3 && <span className="text-[10px] text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">+{s.programmes.length - 3} more</span>}
                </div>

                {/* Deadline + actions */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-100 mt-auto">
                  <div>
                    <p className="text-[10px] text-slate-400 font-medium">Deadline</p>
                    <p className={`text-xs font-bold ${urgent ? "text-red-600" : "text-slate-700"}`}>{s.deadline}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={e => { e.stopPropagation(); navigate(`/student/scholarships/${s.id}`); }}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors">
                      Details
                    </button>
                    <button
                      onClick={e => e.stopPropagation()}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors">
                      Apply Now
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
