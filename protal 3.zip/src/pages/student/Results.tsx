import { student } from "../../data/mock";
import { ProgressBar } from "../../ui";

export default function Results() {
  const gpa = (student.subjects.reduce((s, x) => s + x.score, 0) / student.subjects.length / 20).toFixed(2);

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Academic Results</h1>
          <p className="text-slate-500 text-sm mt-1">Your verified examination results</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-green-600 font-semibold bg-green-50 px-2.5 py-1.5 rounded-full">✓ Verified by SPM</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[["GPA", gpa, "out of 5.0"], ["Subjects", student.subjects.length.toString(), "completed"], ["Grade A", student.subjects.filter(s => s.grade === "A").length.toString(), "subjects"]].map(([l, v, s]) => (
          <div key={l} className="bg-white rounded-2xl border border-slate-200 p-5 text-center">
            <p className="text-3xl font-bold text-slate-900">{v}</p>
            <p className="text-xs text-slate-400 mt-1">{s}</p>
            <p className="text-xs font-semibold text-slate-600 mt-0.5">{l}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <p className="text-sm font-semibold text-slate-700">Subject Results</p>
          <button className="text-xs text-blue-600 font-semibold hover:underline">Download Certificate</button>
        </div>
        <div className="divide-y divide-slate-50">
          {student.subjects.map((s, i) => (
            <div key={i} className="flex items-center gap-4 px-5 py-4 hover:bg-slate-50 transition-colors">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold shrink-0 ${s.grade === "A" ? "bg-green-50 text-green-700" : s.grade === "B" ? "bg-blue-50 text-blue-700" : "bg-amber-50 text-amber-700"}`}>
                {s.grade}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-800">{s.subject}</p>
                <div className="mt-1.5">
                  <ProgressBar value={s.score} color={s.grade === "A" ? "#16A34A" : s.grade === "B" ? "#2563EB" : "#D97706"} />
                </div>
              </div>
              <div className="text-right shrink-0">
                <p className="text-sm font-bold text-slate-800">{s.score}%</p>
                {s.verified && <p className="text-[10px] text-green-500 font-semibold">Verified</p>}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-5 text-white">
        <p className="text-sm font-semibold opacity-90 mb-3">AI Course Eligibility Analysis</p>
        <p className="text-base leading-relaxed">Based on your results, you are eligible for <span className="font-bold">38 programmes</span> across 18 institutions. Your strongest match subjects are <span className="font-bold">Mathematics</span> and <span className="font-bold">Physics</span>, unlocking engineering and computing tracks.</p>
        <button className="mt-4 px-4 py-2 bg-white text-blue-700 rounded-xl text-xs font-bold hover:bg-blue-50 transition-colors">View Eligible Courses →</button>
      </div>
    </div>
  );
}
