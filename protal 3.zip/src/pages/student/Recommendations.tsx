import { useState } from "react";
import { useNavigate } from "react-router";
import { courses } from "../../data/mock";
import { MatchRing, Badge } from "../../ui";

const TABS = ["Best Matches", "Strong Matches", "Alternative Pathways"];

export default function Recommendations() {
  const navigate = useNavigate();
  const [tab, setTab] = useState("Best Matches");

  const grouped = {
    "Best Matches": courses.filter(c => c.match >= 90),
    "Strong Matches": courses.filter(c => c.match >= 75 && c.match < 90),
    "Alternative Pathways": courses.filter(c => c.match < 75),
  };
  const list = grouped[tab as keyof typeof grouped] ?? courses;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Courses Recommended for You</h1>
          <p className="text-slate-500 text-sm mt-1">Personalised based on your results, interests and career goals</p>
        </div>
        <div className="text-right"><p className="text-2xl font-bold text-slate-900">43</p><p className="text-xs text-slate-500">matching programmes</p></div>
      </div>

      {/* Weighting */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <p className="text-xs font-semibold text-slate-600 mb-3">Recommendation weights</p>
        <div className="grid grid-cols-4 gap-3 sm:grid-cols-7">
          {[["Academic", 30], ["Subjects", 20], ["Career", 15], ["Cost", 15], ["Preference", 10], ["Location", 5], ["Availability", 5]].map(([l, w]) => (
            <div key={l} className="text-center">
              <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden mb-1.5">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: `${(w as number) * 3}%` }} />
              </div>
              <p className="text-[10px] text-slate-500">{l}</p>
              <p className="text-[10px] font-bold text-slate-700">{w}%</p>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-1 bg-slate-100 p-1 rounded-xl w-fit">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${tab === t ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
            {t} <span className={`ml-1 text-[10px] font-bold ${tab === t ? "text-blue-600" : "text-slate-400"}`}>({grouped[t as keyof typeof grouped]?.length ?? 0})</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {list.map(c => (
          <div key={c.id} className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col gap-3 hover:shadow-md hover:border-slate-300 transition-all">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-slate-900 text-white text-[10px] font-bold flex items-center justify-center shrink-0">{c.logo}</div>
                <div><p className="text-[10px] text-slate-400">{c.institution}</p><p className="text-xs font-semibold text-slate-800 leading-snug mt-0.5">{c.name}</p></div>
              </div>
              <MatchRing score={c.match} size={44} />
            </div>
            <div className="flex flex-wrap gap-1.5">
              <Badge status={c.eligible ? "Eligible" : "Conditional"} />
              {c.scholarship && <span className="px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 text-[11px] font-semibold">🎓 Scholarship</span>}
            </div>
            <div className="grid grid-cols-2 gap-1 text-xs mt-auto">
              <div className="bg-slate-50 rounded-lg p-2 text-center"><p className="text-[10px] text-slate-400">Tuition</p><p className="font-semibold text-slate-700 mt-0.5">{c.tuition}</p></div>
              <div className="bg-slate-50 rounded-lg p-2 text-center"><p className="text-[10px] text-slate-400">Duration</p><p className="font-semibold text-slate-700 mt-0.5">{c.duration}</p></div>
            </div>
            <button onClick={() => navigate(`/student/courses/${c.id}`)} className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold py-2 rounded-xl transition-colors">View Course</button>
          </div>
        ))}
        {list.length === 0 && (
          <div className="col-span-4 flex flex-col items-center justify-center py-16 text-center">
            <div className="text-4xl mb-3">🔍</div>
            <p className="text-slate-600 font-semibold">No courses in this category</p>
          </div>
        )}
      </div>
    </div>
  );
}
