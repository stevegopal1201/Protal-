import { useState } from "react";
import { useParams, useNavigate } from "react-router";
import { scholarships } from "../../data/mock";
import { MatchRing, Badge } from "../../ui";

const TABS = ["Overview", "Eligibility", "Funding", "Application"];

export default function ScholarshipDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tab, setTab] = useState("Overview");
  const s = scholarships.find(x => x.id === Number(id)) ?? scholarships[0];

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <button onClick={() => navigate(-1)} className="text-sm text-slate-500 hover:text-slate-700 font-medium flex items-center gap-1">← Back</button>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <div className="flex items-start gap-5">
          <div className="w-14 h-14 rounded-2xl bg-purple-100 flex items-center justify-center text-3xl shrink-0">🎓</div>
          <div className="flex-1">
            <div className="flex items-start justify-between gap-4">
              <div>
                <Badge status={s.type} />
                <h1 className="text-xl font-bold text-slate-900 mt-2">{s.name}</h1>
                <p className="text-sm text-slate-400 mt-0.5">{s.provider}</p>
              </div>
              <MatchRing score={s.match} size={72} />
            </div>
            <div className="grid grid-cols-4 gap-3 mt-5 pt-5 border-t border-slate-100 text-center">
              {[["Tuition", s.tuition], ["Living", s.living], ["Deadline", s.deadline], ["Recipients", `${s.recipients}/yr`]].map(([l, v]) => (
                <div key={l}><p className={`text-sm font-semibold ${l === "Deadline" && s.daysLeft <= 14 ? "text-red-600" : "text-slate-800"}`}>{v}</p><p className="text-xs text-slate-400 mt-0.5">{l}</p></div>
              ))}
            </div>
          </div>
        </div>
        <div className="flex gap-3 mt-5">
          <button className="flex-1 max-w-xs bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 rounded-xl text-sm transition-colors">Apply Now</button>
          <button className="px-5 py-2.5 border border-slate-200 hover:border-slate-300 text-slate-600 font-semibold text-sm rounded-xl transition-colors">Save</button>
        </div>
      </div>

      <div className="flex overflow-x-auto border-b border-slate-200">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-5 py-3 text-sm font-semibold whitespace-nowrap border-b-2 transition-colors ${tab === t ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500 hover:text-slate-700"}`}>
            {t}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        {tab === "Overview" && (
          <div className="space-y-4">
            <p className="text-sm text-slate-600 leading-relaxed">{s.description}</p>
            <div>
              <p className="text-sm font-semibold text-slate-700 mb-2">Eligible Programmes</p>
              <div className="flex flex-wrap gap-2">
                {s.programmes.map(p => <span key={p} className="px-3 py-1.5 bg-blue-50 text-blue-700 text-xs font-semibold rounded-full">{p}</span>)}
              </div>
            </div>
          </div>
        )}

        {tab === "Eligibility" && (
          <div className="space-y-3">
            <p className="text-sm font-semibold text-slate-700">Your Eligibility Check</p>
            {Object.entries(s.eligibility).map(([key, met]) => {
              const labels: Record<string, string> = {
                academic: "Academic Grade Requirement", mathematics: "Mathematics Requirement",
                programme: "Programme Requirement", institution: "Institution Requirement",
                financial: "Financial Income Requirement", nationality: "Nationality Requirement",
              };
              return (
                <div key={key} className={`flex items-center justify-between p-4 rounded-xl border ${met ? "bg-green-50 border-green-100" : "bg-red-50 border-red-100"}`}>
                  <span className={`text-sm font-medium ${met ? "text-green-800" : "text-red-700"}`}>{labels[key]}</span>
                  <span className={`text-lg ${met ? "text-green-600" : "text-red-500"}`}>{met ? "✓" : "✗"}</span>
                </div>
              );
            })}
            {Object.values(s.eligibility).every(v => v) && (
              <div className="bg-green-600 text-white rounded-xl p-4 text-center">
                <p className="font-semibold text-sm">You are fully eligible for this scholarship</p>
              </div>
            )}
          </div>
        )}

        {tab === "Funding" && (
          <div className="space-y-3">
            {[["Tuition Coverage", s.tuition, "Per academic year"], ["Living Allowance", s.living, "Monthly stipend"], ["Total Value", `RM ${s.value.toLocaleString()}`, "Estimated over programme duration"]].map(([l, v, sub]) => (
              <div key={l} className="flex items-center justify-between bg-slate-50 rounded-xl p-4">
                <div><p className="text-sm font-semibold text-slate-800">{l}</p><p className="text-xs text-slate-400 mt-0.5">{sub}</p></div>
                <span className="text-base font-bold text-green-700">{v}</span>
              </div>
            ))}
          </div>
        )}

        {tab === "Application" && (
          <div className="space-y-4">
            <div className="space-y-3">
              {["Submit Application Form", "Provide Academic Documents", "Personal Statement", "Referee Letters", "Online Interview"].map((step, i) => (
                <div key={step} className="flex items-center gap-3.5">
                  <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-600 text-xs font-bold flex items-center justify-center shrink-0">{i + 1}</div>
                  <p className="text-sm text-slate-700">{step}</p>
                </div>
              ))}
            </div>
            <div className={`rounded-xl p-4 flex items-center gap-3 ${s.daysLeft <= 14 ? "bg-red-50 border border-red-100" : "bg-amber-50 border border-amber-100"}`}>
              <span className="text-xl">⏰</span>
              <div>
                <p className={`text-sm font-semibold ${s.daysLeft <= 14 ? "text-red-800" : "text-amber-800"}`}>Deadline: {s.deadline}</p>
                <p className={`text-xs mt-0.5 ${s.daysLeft <= 14 ? "text-red-600" : "text-amber-600"}`}>{s.daysLeft} days remaining</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
