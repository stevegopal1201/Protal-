import { useState } from "react";
import { useNavigate } from "react-router";
import { courses } from "../../data/mock";
import { MatchRing, Badge } from "../../ui";

export default function CourseDiscovery() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [eligibleOnly, setEligibleOnly] = useState(false);
  const [scholarshipOnly, setScholarshipOnly] = useState(false);
  const [sort, setSort] = useState("Best Match");

  const filtered = courses
    .filter(c => !eligibleOnly || c.eligible)
    .filter(c => !scholarshipOnly || c.scholarship)
    .filter(c => c.name.toLowerCase().includes(search.toLowerCase()) || c.institution.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-slate-900">Find Your Course</h1>
        <p className="text-slate-500 text-sm mt-1">Browse 245 programmes across 18 institutions</p>
      </div>

      <div className="flex gap-5">
        {/* Filters */}
        <div className="w-52 shrink-0 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-4">
            <p className="text-xs font-semibold text-slate-700">Filters</p>
            {[["Country", ["Any", "Malaysia", "Singapore", "Australia"]], ["Qualification", ["Any", "Diploma", "Bachelor's", "Master's"]], ["Study Mode", ["Any", "Full-time", "Part-time", "Online"]]].map(([l, opts]) => (
              <div key={l as string}>
                <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wide mb-1.5">{l as string}</label>
                <select className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg outline-none focus:border-blue-400 bg-white text-slate-700">
                  {(opts as string[]).map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
            ))}
            <div className="space-y-2.5">
              {[["Eligible Only", eligibleOnly, setEligibleOnly], ["With Scholarship", scholarshipOnly, setScholarshipOnly]].map(([l, v, fn]) => (
                <label key={l as string} className="flex items-center gap-2.5 cursor-pointer">
                  <input type="checkbox" checked={v as boolean} onChange={e => (fn as (b: boolean) => void)(e.target.checked)} className="accent-blue-600 w-3.5 h-3.5" />
                  <span className="text-xs text-slate-600 font-medium">{l as string}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-2">
            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wide">Tuition Range</label>
            <input type="range" min="0" max="60000" step="5000" defaultValue="40000" className="w-full accent-blue-600" />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>RM 0</span><span className="text-blue-600 font-medium">RM 40K</span>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="flex-1 space-y-4">
          <div className="flex gap-3">
            <div className="relative flex-1">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
              <input type="text" placeholder="Search courses, universities…" value={search} onChange={e => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-400 transition-all" />
            </div>
            <select value={sort} onChange={e => setSort(e.target.value)}
              className="px-4 py-2 text-sm bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-400 font-medium text-slate-700">
              {["Best Match", "Lowest Cost", "Highest Scholarship", "Shortest Duration"].map(o => <option key={o}>{o}</option>)}
            </select>
          </div>

          <p className="text-sm text-slate-500"><span className="font-semibold text-slate-800">{filtered.length} programmes</span> found</p>

          {filtered.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {filtered.map(c => (
                <div key={c.id} className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col gap-3 hover:shadow-md hover:border-slate-300 transition-all">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-slate-900 text-white text-[10px] font-bold flex items-center justify-center shrink-0">{c.logo}</div>
                      <div>
                        <p className="text-[10px] text-slate-400">{c.institution}</p>
                        <p className="text-xs font-semibold text-slate-800 leading-snug mt-0.5">{c.name}</p>
                      </div>
                    </div>
                    <MatchRing score={c.match} size={44} />
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    <Badge status={c.eligible ? "Eligible" : "Conditional"} />
                    {c.scholarship && <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 text-[11px] font-semibold">🎓 Scholarship</span>}
                  </div>
                  <div className="grid grid-cols-3 gap-1 text-center">
                    {[["Tuition", c.tuition], ["Duration", c.duration], ["Location", c.location]].map(([k, v]) => (
                      <div key={k} className="bg-slate-50 rounded-lg p-2">
                        <p className="text-[9px] text-slate-400">{k}</p>
                        <p className="text-[10px] font-semibold text-slate-700 mt-0.5 truncate">{v}</p>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-auto">
                    <button onClick={() => navigate(`/student/courses/${c.id}`)} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold py-2 rounded-xl transition-colors">View Course</button>
                    <button className="px-3 py-2 border border-slate-200 text-slate-500 text-xs rounded-xl hover:border-slate-300 transition-colors">Save</button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="text-5xl mb-3">🔍</div>
              <p className="text-lg font-semibold text-slate-700">No courses found</p>
              <p className="text-sm text-slate-400 mt-1">Try adjusting your search or filters</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
