import { useNavigate } from "react-router";
import { student, courses, scholarships, applications } from "../../data/mock";
import { MatchRing, Badge, ProgressBar } from "../../ui";

function StatCard({ icon, value, label, sub, color }: { icon: string; value: string; label: string; sub: string; color: string }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg mb-3 ${color}`}>{icon}</div>
      <p className="text-2xl font-bold text-slate-800">{value}</p>
      <p className="text-xs font-medium text-slate-500 mt-0.5">{label}</p>
      <p className="text-[11px] text-slate-400 mt-0.5">{sub}</p>
    </div>
  );
}

function CourseCard({ c, onView }: { c: typeof courses[0]; onView: () => void }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col gap-3 hover:shadow-md hover:border-slate-300 transition-all">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-slate-900 flex items-center justify-center text-white text-[10px] font-bold shrink-0">{c.logo}</div>
          <div>
            <p className="text-[10px] text-slate-400 font-medium">{c.institution}</p>
            <p className="text-xs font-semibold text-slate-800 leading-snug mt-0.5">{c.name}</p>
          </div>
        </div>
        <MatchRing score={c.match} size={44} />
      </div>
      <div className="flex flex-wrap gap-1.5">
        <Badge status={c.eligible ? "Eligible" : "Conditional"} />
        {c.scholarship && <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 text-[11px] font-semibold">🎓 Scholarship</span>}
      </div>
      <div className="grid grid-cols-3 gap-1.5 text-center">
        {[["Tuition", c.tuition], ["Duration", c.duration], ["Location", c.location]].map(([k, v]) => (
          <div key={k} className="bg-slate-50 rounded-lg p-2">
            <p className="text-[10px] text-slate-400">{k}</p>
            <p className="text-[11px] font-semibold text-slate-700 mt-0.5 truncate">{v}</p>
          </div>
        ))}
      </div>
      <button onClick={onView} className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold py-2 rounded-xl transition-colors mt-auto">
        View Course
      </button>
    </div>
  );
}

function ScholarshipCard({ s, onView }: { s: typeof scholarships[0]; onView: () => void }) {
  const urgent = s.daysLeft <= 14;
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col gap-3 hover:shadow-md hover:border-slate-300 transition-all">
      <div className="flex items-start justify-between">
        <div>
          <Badge status={s.type} />
          <p className="text-xs font-semibold text-slate-800 leading-snug mt-2">{s.name}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">{s.provider}</p>
        </div>
        <MatchRing score={s.match} size={44} />
      </div>
      <div className="space-y-1 text-xs">
        {[["Tuition", s.tuition], ["Living", s.living], ["Deadline", s.deadline]].map(([k, v]) => (
          <div key={k} className="flex justify-between">
            <span className="text-slate-400">{k}</span>
            <span className={`font-semibold ${k === "Deadline" && urgent ? "text-red-600" : "text-slate-700"}`}>
              {v}{k === "Deadline" && urgent ? ` (${s.daysLeft}d)` : ""}
            </span>
          </div>
        ))}
      </div>
      <button onClick={onView} className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold py-2 rounded-xl transition-colors mt-auto">
        View & Apply
      </button>
    </div>
  );
}

export default function StudentDashboard() {
  const navigate = useNavigate();
  const h = new Date().getHours();
  const greeting = h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Welcome */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-slate-500 text-sm">{greeting} 👋</p>
          <h1 className="text-2xl font-bold text-slate-900">{student.name}</h1>
        </div>
        <button onClick={() => navigate("/student/onboarding")} className="text-sm font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 px-4 py-2 rounded-xl transition-colors">
          Complete Onboarding →
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon="📚" value="43" label="Course Matches" sub="38 eligible" color="bg-blue-50 text-blue-600" />
        <StatCard icon="🎓" value="12" label="Scholarships" sub="3 fully funded" color="bg-purple-50 text-purple-600" />
        <StatCard icon="📋" value="3" label="Applications" sub="1 under review" color="bg-amber-50 text-amber-600" />
        <StatCard icon="👤" value={`${student.completion}%`} label="Profile" sub="Nearly complete" color="bg-green-50 text-green-600" />
      </div>

      {/* Academic + Profile + Applications */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Academic snapshot */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
          <p className="text-sm font-semibold text-slate-800">Academic Snapshot</p>
          <div className="grid grid-cols-3 gap-2 text-center">
            {[["5", "Subjects"], ["A/B", "Overall"], ["3.7", "GPA"]].map(([v, l]) => (
              <div key={l} className="bg-slate-50 rounded-xl p-3">
                <p className="text-lg font-bold text-slate-800">{v}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">{l}</p>
              </div>
            ))}
          </div>
          <div className="space-y-2">
            {student.subjects.map(s => (
              <div key={s.subject} className="flex items-center gap-2.5">
                <span className="w-24 text-xs text-slate-600 shrink-0 truncate">{s.subject}</span>
                <div className="flex-1">
                  <ProgressBar value={s.score} color={s.score >= 80 ? "#16A34A" : s.score >= 65 ? "#2563EB" : "#D97706"} />
                </div>
                <span className={`text-xs font-bold w-5 text-right shrink-0 ${s.grade === "A" ? "text-green-600" : s.grade === "B" ? "text-blue-600" : "text-amber-600"}`}>{s.grade}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Profile */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
          <p className="text-sm font-semibold text-slate-800">Profile Readiness</p>
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-500">Completion</span>
              <span className="font-bold text-slate-800">{student.completion}%</span>
            </div>
            <ProgressBar value={student.completion} color="#16A34A" />
          </div>
          <div className="space-y-2.5">
            {[
              { label: "Personal Info", done: true },
              { label: "Education History", done: true },
              { label: "Exam Results", done: true },
              { label: "Career Interests", done: true },
              { label: "Certificate Uploaded", done: false },
            ].map(item => (
              <div key={item.label} className="flex items-center justify-between text-xs">
                <span className={item.done ? "text-slate-600" : "text-slate-400"}>{item.label}</span>
                <span>{item.done ? "✅" : "⏳"}</span>
              </div>
            ))}
          </div>
          <button onClick={() => navigate("/student/profile")} className="w-full text-xs text-blue-600 font-semibold bg-blue-50 hover:bg-blue-100 py-2 rounded-xl transition-colors">
            Update Profile
          </button>
        </div>

        {/* Applications */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <p className="text-sm font-semibold text-slate-800">Applications</p>
          {applications.map(app => (
            <div key={app.id} onClick={() => navigate("/student/applications")}
              className="border border-slate-100 rounded-xl p-3 hover:border-slate-200 cursor-pointer transition-colors">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div>
                  <p className="text-xs font-semibold text-slate-700 leading-snug">{app.course}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{app.institution}</p>
                </div>
                <Badge status={app.status} />
              </div>
              <div className="flex gap-1">
                {app.steps.map((_, i) => (
                  <div key={i} className={`flex-1 h-1 rounded-full ${i <= app.step ? "bg-blue-500" : "bg-slate-100"}`} />
                ))}
              </div>
              <p className="text-[10px] text-slate-400 mt-1">{app.steps[app.step]}</p>
            </div>
          ))}
          <button onClick={() => navigate("/student/applications")} className="w-full text-xs text-blue-600 font-semibold hover:underline">
            View All →
          </button>
        </div>
      </div>

      {/* Recommended Courses */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-slate-800">Recommended for You</h2>
          <button onClick={() => navigate("/student/recommendations")} className="text-xs text-blue-600 font-semibold hover:underline">View All →</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {courses.map(c => <CourseCard key={c.id} c={c} onView={() => navigate(`/student/courses/${c.id}`)} />)}
        </div>
      </div>

      {/* Scholarships */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-slate-800">Matching Scholarships</h2>
          <button onClick={() => navigate("/student/scholarships")} className="text-xs text-blue-600 font-semibold hover:underline">View All →</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {scholarships.map(s => <ScholarshipCard key={s.id} s={s} onView={() => navigate(`/student/scholarships/${s.id}`)} />)}
        </div>
      </div>

      {/* Deadlines */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <h2 className="text-base font-semibold text-slate-800 mb-4">Upcoming Deadlines</h2>
        <div className="space-y-3">
          {[...scholarships].sort((a, b) => a.daysLeft - b.daysLeft).map(s => (
            <div key={s.id} className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center shrink-0 ${s.daysLeft <= 14 ? "bg-red-50" : "bg-amber-50"}`}>
                <p className={`text-xs font-bold leading-none ${s.daysLeft <= 14 ? "text-red-600" : "text-amber-600"}`}>{s.daysLeft}</p>
                <p className={`text-[9px] ${s.daysLeft <= 14 ? "text-red-400" : "text-amber-400"}`}>days</p>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-700 truncate">{s.name}</p>
                <p className="text-xs text-slate-400">{s.provider} · Due {s.deadline}</p>
              </div>
              <button onClick={() => navigate(`/student/scholarships/${s.id}`)} className="text-xs text-blue-600 font-semibold hover:underline shrink-0">
                Apply →
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
