import { useState } from "react";
import { courses } from "../../data/mock";
import { MatchRing } from "../../ui";

export default function Compare() {
  const [selected, setSelected] = useState<number[]>([1, 2]);

  const toggle = (id: number) => {
    if (selected.includes(id)) {
      setSelected(s => s.filter(x => x !== id));
    } else if (selected.length < 3) {
      setSelected(s => [...s, id]);
    }
  };

  const cols = courses.filter(c => selected.includes(c.id));
  const ROWS = [
    { label: "Institution", key: (c: typeof courses[0]) => c.institution },
    { label: "Duration", key: (c: typeof courses[0]) => c.duration },
    { label: "Mode", key: (c: typeof courses[0]) => c.mode },
    { label: "Location", key: (c: typeof courses[0]) => c.location },
    { label: "Annual Tuition", key: (c: typeof courses[0]) => c.tuition },
    { label: "Scholarship", key: (c: typeof courses[0]) => c.scholarship ? "Available" : "None" },
    { label: "Eligible", key: (c: typeof courses[0]) => c.eligible ? "Yes ✓" : "No" },
  ];

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Compare Courses</h1>
        <p className="text-slate-500 text-sm mt-1">Select up to 3 courses to compare side-by-side</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {courses.map(c => (
          <button key={c.id} onClick={() => toggle(c.id)}
            className={`p-3 rounded-2xl border text-left transition-all ${selected.includes(c.id) ? "border-blue-600 bg-blue-50 shadow-md shadow-blue-100" : "border-slate-200 bg-white hover:border-slate-300"}`}>
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-lg bg-slate-900 text-white text-[10px] font-bold flex items-center justify-center">{c.logo}</div>
              {selected.includes(c.id) && <span className="text-[10px] font-bold text-blue-600 bg-blue-100 px-1.5 py-0.5 rounded-full">#{selected.indexOf(c.id) + 1}</span>}
            </div>
            <p className="text-xs font-semibold text-slate-800 leading-snug">{c.name}</p>
            <p className="text-[10px] text-slate-400 mt-0.5 truncate">{c.institution}</p>
          </button>
        ))}
      </div>

      {cols.length >= 2 && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          {/* Header */}
          <div className="grid gap-0" style={{ gridTemplateColumns: `180px repeat(${cols.length}, 1fr)` }}>
            <div className="bg-slate-50 p-4 border-b border-r border-slate-200" />
            {cols.map(c => (
              <div key={c.id} className="p-4 border-b border-r border-slate-100 last:border-r-0 text-center">
                <p className="text-xs font-bold text-slate-800 leading-snug">{c.name}</p>
                <div className="flex justify-center mt-2">
                  <MatchRing score={c.match} size={52} />
                </div>
                <p className="text-[10px] text-green-600 font-semibold mt-1">{c.match}% match</p>
              </div>
            ))}
          </div>

          {/* Rows */}
          {ROWS.map((row, ri) => (
            <div key={row.label} className={`grid gap-0 ${ri % 2 === 0 ? "bg-white" : "bg-slate-50/50"}`}
              style={{ gridTemplateColumns: `180px repeat(${cols.length}, 1fr)` }}>
              <div className="p-3.5 px-4 border-r border-slate-100 flex items-center">
                <p className="text-xs font-semibold text-slate-500">{row.label}</p>
              </div>
              {cols.map(c => {
                const val = row.key(c);
                return (
                  <div key={c.id} className="p-3.5 border-r border-slate-100 last:border-r-0 flex items-center justify-center">
                    <p className={`text-xs text-center font-medium ${val === "Yes ✓" ? "text-green-600" : val === "No" ? "text-red-500" : val === "Available" ? "text-blue-600" : "text-slate-700"}`}>{val}</p>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      )}

      {cols.length < 2 && (
        <div className="flex flex-col items-center justify-center py-20 text-center bg-white rounded-2xl border border-slate-200">
          <p className="text-4xl mb-3">⚖️</p>
          <p className="font-semibold text-slate-700">Select at least 2 courses to compare</p>
        </div>
      )}
    </div>
  );
}
