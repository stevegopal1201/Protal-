import { useState } from "react";
import { useNavigate } from "react-router";
import { courses } from "../../data/mock";

export default function FinancialAid() {
  const navigate = useNavigate();
  const [sel, setSel] = useState(1);
  const c = courses.find(x => x.id === sel) ?? courses[0];
  const total = Object.values(c.fees).reduce((a, b) => a + b, 0);
  const scholarship = 20000;
  const bursary = 5000;
  const yourCost = total - scholarship - bursary;

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Can I Afford This Programme?</h1>
        <p className="text-slate-500 text-sm mt-1">See your estimated cost after scholarships and financial aid</p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <label className="block text-xs font-semibold text-slate-600 mb-2">Select Programme</label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {courses.map(c => (
            <button key={c.id} onClick={() => setSel(c.id)}
              className={`p-3 rounded-xl border text-left transition-all ${sel === c.id ? "border-blue-600 bg-blue-50" : "border-slate-200 hover:border-slate-300"}`}>
              <p className={`text-xs font-semibold truncate ${sel === c.id ? "text-blue-700" : "text-slate-700"}`}>{c.name}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">{c.tuition}</p>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Cost breakdown */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <p className="text-sm font-semibold text-slate-800">Cost Breakdown</p>
          {Object.entries(c.fees).map(([key, val]) => (
            <div key={key} className="flex justify-between text-sm">
              <span className="text-slate-500 capitalize">{key}</span>
              <span className="font-medium text-slate-700">RM {val.toLocaleString()}</span>
            </div>
          ))}
          <div className="border-t border-slate-200 pt-3 flex justify-between">
            <span className="text-sm font-bold text-slate-800">Total / Year</span>
            <span className="text-sm font-bold text-slate-900">RM {total.toLocaleString()}</span>
          </div>
        </div>

        {/* Aid summary */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <p className="text-sm font-semibold text-slate-800">Financial Aid Summary</p>
          <div className="space-y-2">
            <div className="flex justify-between items-center py-2 border-b border-slate-100">
              <span className="text-sm text-slate-600">Total Cost</span>
              <span className="text-sm font-semibold text-slate-800">RM {total.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-100">
              <div><p className="text-sm text-green-700 font-medium">Future Technology Scholarship</p><p className="text-[11px] text-slate-400">ABC Foundation · 96% Match</p></div>
              <span className="text-sm font-semibold text-green-600">- RM {scholarship.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-100">
              <div><p className="text-sm text-green-700 font-medium">Digital Malaysia Bursary</p><p className="text-[11px] text-slate-400">MDEC · Partial Funding</p></div>
              <span className="text-sm font-semibold text-green-600">- RM {bursary.toLocaleString()}</span>
            </div>
          </div>
          <div className="bg-blue-600 rounded-xl p-4 flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-xs">Your Estimated Cost</p>
              <p className="text-white text-2xl font-bold mt-0.5">RM {yourCost.toLocaleString()}</p>
              <p className="text-blue-200 text-xs mt-1">{Math.round((1 - yourCost / total) * 100)}% covered by aid</p>
            </div>
            <div className="w-16 h-16 relative flex items-center justify-center">
              <svg viewBox="0 0 60 60" className="absolute inset-0 rotate-[-90deg]">
                <circle cx="30" cy="30" r="24" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="6" />
                <circle cx="30" cy="30" r="24" fill="none" stroke="white" strokeWidth="6"
                  strokeLinecap="round" strokeDasharray={`${2 * Math.PI * 24 * yourCost / total} ${2 * Math.PI * 24 * (1 - yourCost / total)}`} />
              </svg>
              <span className="text-white text-xs font-bold">{Math.round(yourCost / total * 100)}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Affordable alternatives */}
      <div>
        <h2 className="text-base font-semibold text-slate-800 mb-3">More Affordable Alternatives</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {courses.filter(x => x.id !== sel).slice(0, 3).map(alt => (
            <div key={alt.id} className="bg-white rounded-2xl border border-slate-200 p-4 hover:border-slate-300 transition-colors">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-slate-900 text-white text-[10px] font-bold flex items-center justify-center shrink-0">{alt.logo}</div>
                <div><p className="text-xs font-semibold text-slate-700 truncate">{alt.name}</p><p className="text-[10px] text-slate-400">{alt.tuition}/yr</p></div>
              </div>
              <button onClick={() => navigate(`/student/courses/${alt.id}`)} className="w-full text-xs text-blue-600 font-semibold hover:underline">View Course →</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
