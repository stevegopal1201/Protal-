import { useState, useRef, useEffect } from "react";
import { aiSuggestions } from "../../data/mock";

type Msg = { role: "user" | "assistant"; content: string; courses?: { name: string; institution: string; match: number; cost: string }[] };

const CANNED: Record<string, Msg> = {
  "What can I study with my results?": {
    role: "assistant",
    content: "Based on your A/B results with strong performance in Mathematics and Physics, you qualify for 38 programmes in Computing, Engineering, and Technology. Your top matches are Computer Science (94%) and Software Engineering (89%).",
    courses: [
      { name: "Bachelor of Computer Science", institution: "Universiti Malaya", match: 94, cost: "RM 25,000/yr" },
      { name: "Bachelor of Software Engineering", institution: "UTM", match: 89, cost: "RM 21,000/yr" },
    ],
  },
  "Which course is the cheapest?": {
    role: "assistant",
    content: "The most affordable option matching your profile is Bachelor of Data Science at Multimedia University at RM 18,000 per year. Note: you may need a bridging module for Statistics.",
    courses: [{ name: "Bachelor of Data Science", institution: "Multimedia University", match: 81, cost: "RM 18,000/yr" }],
  },
  "Which scholarships can I get?": {
    role: "assistant",
    content: "You qualify for 12 scholarships. Your top match is the Future Technology Scholarship (96%) — fully funded, covering 100% tuition plus RM 1,500/month living allowance. Deadline in 33 days.",
  },
  "Show me fully funded options": {
    role: "assistant",
    content: "I found 2 fully funded scholarships for your profile: Future Technology Scholarship (96% match) and Yayasan Petronas Scholarship (74%). Note that Petronas deadline is in 5 days — act fast!",
  },
};

const INIT: Msg[] = [{
  role: "assistant",
  content: "Hello Steve! Based on your A/B academic results and interest in technology, I've found 43 suitable computing programmes across 18 institutions. You're eligible for 38 of them, and 12 have scholarship opportunities. Where would you like to start?",
}];

export default function AIAdvisor() {
  const [msgs, setMsgs] = useState<Msg[]>(INIT);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => { bottom.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, typing]);

  function send(text: string) {
    if (!text.trim() || typing) return;
    setMsgs(p => [...p, { role: "user", content: text }]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      const reply = CANNED[text] ?? { role: "assistant" as const, content: `I understand you're asking about "${text}". Let me analyse your profile. Based on your results and career goals, I can suggest several pathways. Would you like me to focus on courses, scholarships, or career options?` };
      setMsgs(p => [...p, reply]);
      setTyping(false);
    }, 1000);
  }

  return (
    <div className="flex flex-col h-full" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-4 flex items-center gap-3 shrink-0">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-xl">🤖</div>
        <div>
          <p className="text-sm font-semibold text-slate-800">Education Advisor AI</p>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full pulse" />
            <span className="text-xs text-slate-400">Online · Powered by Edvora AI</span>
          </div>
        </div>
        <button onClick={() => setMsgs(INIT)} className="ml-auto px-3 py-1.5 text-xs font-medium text-slate-500 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">Clear Chat</button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
        {msgs.map((msg, i) => (
          <div key={i} className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            {msg.role === "assistant" && (
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-sm shrink-0 mt-0.5">🤖</div>
            )}
            <div className={`max-w-xl flex flex-col gap-3 ${msg.role === "user" ? "items-end" : "items-start"}`}>
              <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${msg.role === "user" ? "bg-blue-600 text-white rounded-br-sm" : "bg-white border border-slate-200 text-slate-700 rounded-bl-sm shadow-sm"}`}>
                {msg.content}
              </div>
              {msg.courses?.map((c, j) => (
                <div key={j} className="bg-white border border-slate-200 rounded-xl p-3 shadow-sm flex items-center justify-between gap-3 w-full">
                  <div>
                    <p className="text-xs font-semibold text-slate-800">{c.name}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">{c.institution} · {c.cost}</p>
                  </div>
                  <div className="text-center shrink-0">
                    <p className="text-lg font-bold text-green-600">{c.match}%</p>
                    <p className="text-[9px] text-slate-400">match</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
        {typing && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-sm shrink-0">🤖</div>
            <div className="bg-white border border-slate-200 rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm">
              <div className="flex gap-1.5 items-center h-4">
                {[0, 1, 2].map(i => (
                  <span key={i} className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottom} />
      </div>

      {/* Suggestions */}
      <div className="px-6 py-3 border-t border-slate-100 bg-white">
        <div className="flex gap-2 flex-wrap">
          {aiSuggestions.map(q => (
            <button key={q} onClick={() => send(q)}
              className="px-3 py-1.5 text-xs font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-full border border-blue-100 transition-colors">
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="px-6 py-4 border-t border-slate-200 bg-white shrink-0">
        <div className="flex gap-3">
          <input
            type="text" value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && !e.shiftKey && send(input)}
            placeholder="Ask me anything about your education journey…"
            className="flex-1 px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-400 focus:bg-white transition-all"
          />
          <button onClick={() => send(input)} disabled={!input.trim() || typing}
            className="px-5 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white font-semibold rounded-xl transition-colors text-sm">
            Send
          </button>
        </div>
      </div>
    </div>
  );
}
