import { useState } from "react";
import { applications } from "../../data/mock";
import { Badge } from "../../ui";

const TABS = ["All", "Draft", "Submitted", "Under Review", "Interview", "Accepted", "Rejected"];

export default function Applications() {
  const [tab, setTab] = useState("All");
  const filtered = tab === "All" ? applications : applications.filter(a => a.status === tab);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">My Applications</h1>
          <p className="text-slate-500 text-sm mt-1">{applications.length} applications</p>
        </div>
        <button className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-colors">+ New Application</button>
      </div>

      <div className="flex gap-1 flex-wrap">
        {TABS.map(t => {
          const count = t === "All" ? applications.length : applications.filter(a => a.status === t).length;
          return (
            <button key={t} onClick={() => setTab(t)}
              className={`px-3 py-2 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5 ${tab === t ? "bg-blue-600 text-white" : "text-slate-500 hover:text-slate-700 hover:bg-slate-100"}`}>
              {t}
              {count > 0 && <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${tab === t ? "bg-blue-500" : "bg-slate-200 text-slate-600"}`}>{count}</span>}
            </button>
          );
        })}
      </div>

      <div className="space-y-4">
        {filtered.map(app => (
          <div key={app.id} className="bg-white rounded-2xl border border-slate-200 p-5 hover:border-slate-300 transition-all hover:shadow-sm">
            <div className="flex items-start justify-between gap-4 mb-4">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center justify-center shrink-0">{app.institution.slice(0, 2).toUpperCase()}</div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">{app.course}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{app.institution}</p>
                  <div className="flex items-center gap-3 mt-1.5 text-[11px] text-slate-400">
                    <span>{app.ref}</span><span>·</span><span>Submitted {app.submitted}</span><span>·</span><span>{app.intake}</span>
                  </div>
                </div>
              </div>
              <Badge status={app.status} />
            </div>

            {/* Progress */}
            <div className="flex items-center gap-0 mt-2">
              {app.steps.map((step, i) => (
                <div key={step} className="flex items-center flex-1 last:flex-none">
                  <div className="flex flex-col items-center">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${i < app.step ? "bg-blue-600 text-white" : i === app.step ? "bg-blue-600 text-white ring-4 ring-blue-100" : "bg-slate-100 text-slate-400"}`}>
                      {i < app.step ? "✓" : i + 1}
                    </div>
                    <p className={`text-[9px] mt-1 text-center max-w-[56px] ${i <= app.step ? "text-slate-600 font-medium" : "text-slate-300"}`}>{step}</p>
                  </div>
                  {i < app.steps.length - 1 && <div className={`flex-1 h-0.5 mx-1 mb-4 ${i < app.step ? "bg-blue-500" : "bg-slate-200"}`} />}
                </div>
              ))}
            </div>

            <div className="flex gap-2 mt-4">
              {["View Details", "Upload Documents", "Contact Institution"].map(action => (
                <button key={action} className="px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors">{action}</button>
              ))}
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="text-5xl mb-3">📋</div>
            <p className="text-lg font-semibold text-slate-700">No {tab.toLowerCase()} applications</p>
          </div>
        )}
      </div>
    </div>
  );
}
