import { useState } from "react";
import { useNavigate } from "react-router";
import heroBg from "../imports/picqqq.png";
import logo from "../imports/iooo.png";

type Portal = "student" | "institution" | "admin";

export default function Landing() {
  const navigate = useNavigate();
  const [portal, setPortal] = useState<Portal>("student");
  const [tab, setTab] = useState<"login" | "register">("login");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (portal === "institution") navigate("/institution");
    else if (portal === "admin") navigate("/admin");
    else navigate("/student");
  }

  return (
    <div className="min-h-screen flex relative" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Full-page background */}
      <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroBg})` }} />
      <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(11,31,58,0.88) 0%, rgba(11,31,58,0.60) 45%, rgba(11,31,58,0.40) 100%)" }} />

      {/* Left hero */}
      <div className="hidden lg:flex w-[55%] flex-col justify-between p-14 relative z-10">
        <div className="flex items-center gap-3">
          <img src={logo} alt="Edvora" className="h-12 w-12 object-contain" />
          <div>
            <p className="text-white font-bold text-lg leading-none">Edvora</p>
            <p className="text-white/50 text-xs">Discover. Match. Fund. Succeed.</p>
          </div>
        </div>

        <div className="space-y-8">
          <div>
            <h1 className="text-white font-bold text-[42px] leading-[1.1]">
              Find Your Right<br />Education Pathway
            </h1>
            <p className="text-white/60 mt-4 text-base leading-relaxed max-w-sm">
              Tell us about yourself. We will help you find the right education pathway and funding opportunities tailored to your profile.
            </p>
          </div>
          <div className="space-y-4">
            {[
              { icon: "⭐", title: "AI-Powered Recommendations", desc: "Personalised matches based on your results and goals" },
              { icon: "🎓", title: "Scholarship Matching", desc: "Automatically matched to scholarships you qualify for" },
              { icon: "📊", title: "Eligibility Analysis", desc: "Know instantly if you meet entry requirements" },
            ].map(f => (
              <div key={f.title} className="flex gap-3.5 items-start">
                <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-lg shrink-0">{f.icon}</div>
                <div>
                  <p className="text-white font-semibold text-sm">{f.title}</p>
                  <p className="text-white/40 text-xs mt-0.5">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-4 gap-6">
          {[["1.25M+", "Students"], ["4,250", "Institutions"], ["85K+", "Programmes"], ["12.5K", "Scholarships"]].map(([v, l]) => (
            <div key={l}>
              <p className="text-white font-bold text-xl">{v}</p>
              <p className="text-white/40 text-xs mt-0.5">{l}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Right auth panel */}
      <div className="flex-1 flex items-center justify-center p-8 relative z-10">
        <div className="w-full max-w-sm space-y-6">
          {/* Portal selector */}
          <div className="flex gap-1 p-1 rounded-xl" style={{ background: "rgba(255,255,255,0.15)", backdropFilter: "blur(8px)" }}>
            {(["student", "institution", "admin"] as Portal[]).map(p => (
              <button
                key={p}
                onClick={() => setPortal(p)}
                className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all capitalize ${portal === p ? "bg-white text-slate-800 shadow-sm" : "text-white/70 hover:text-white"}`}
              >
                {p === "student" ? "Student" : p === "institution" ? "Institution" : "Admin"}
              </button>
            ))}
          </div>

          <div className="rounded-2xl p-7" style={{ background: "rgba(255,255,255,0.92)", backdropFilter: "blur(20px)", boxShadow: "0 8px 40px rgba(0,0,0,0.25)" }}>
            {/* Login / Register tabs */}
            <div className="flex gap-1 mb-6">
              {(["login", "register"] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`flex-1 py-2 text-sm font-semibold border-b-2 transition-colors ${tab === t ? "border-blue-600 text-blue-600" : "border-transparent text-slate-400 hover:text-slate-600"}`}
                >
                  {t === "login" ? "Sign In" : "Create Account"}
                </button>
              ))}
            </div>

            {tab === "login" ? (
              <form onSubmit={submit} className="space-y-4">
                {[
                  { label: "Email Address", type: "email", placeholder: "steve@email.com" },
                  { label: "Password", type: "password", placeholder: "••••••••" },
                ].map(f => (
                  <div key={f.label}>
                    <label className="block text-xs font-semibold text-slate-600 mb-1.5">{f.label}</label>
                    <input type={f.type} placeholder={f.placeholder}
                      className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50 transition-all" />
                  </div>
                ))}
                <div className="flex items-center justify-between text-xs">
                  <label className="flex items-center gap-2 text-slate-600 cursor-pointer">
                    <input type="checkbox" className="accent-blue-600" /> Remember me
                  </label>
                  <button type="button" className="text-blue-600 hover:underline font-medium">Forgot password?</button>
                </div>
                <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 rounded-xl text-sm transition-colors">
                  Sign In
                </button>
              </form>
            ) : (
              <form onSubmit={submit} className="space-y-3">
                {[
                  { label: "Full Name", type: "text", placeholder: "Steve Lim" },
                  { label: "Email Address", type: "email", placeholder: "steve@email.com" },
                  { label: "Mobile", type: "tel", placeholder: "+60 12 345 6789" },
                  { label: "Password", type: "password", placeholder: "••••••••" },
                ].map(f => (
                  <div key={f.label}>
                    <label className="block text-xs font-semibold text-slate-600 mb-1.5">{f.label}</label>
                    <input type={f.type} placeholder={f.placeholder}
                      className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50 transition-all" />
                  </div>
                ))}
                <label className="flex items-start gap-2 text-xs text-slate-500 pt-1">
                  <input type="checkbox" className="mt-0.5 accent-blue-600 shrink-0" />
                  <span>I agree to the <span className="text-blue-600 cursor-pointer">Terms</span> and <span className="text-blue-600 cursor-pointer">Privacy Policy</span></span>
                </label>
                <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 rounded-xl text-sm transition-colors">
                  Create Account
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
