export const student = {
  name: "Steve Lim",
  email: "steve.lim@email.com",
  nationality: "Malaysian",
  completion: 92,
  subjects: [
    { subject: "Mathematics", grade: "A", score: 85, verified: true },
    { subject: "English", grade: "B", score: 72, verified: true },
    { subject: "Physics", grade: "A", score: 88, verified: true },
    { subject: "Chemistry", grade: "B", score: 76, verified: true },
    { subject: "Biology", grade: "C", score: 65, verified: true },
  ],
};

export const courses = [
  {
    id: 1, name: "Bachelor of Computer Science", institution: "Universiti Malaya", logo: "UM",
    match: 94, tuition: "RM 25,000", duration: "3 Years", location: "Kuala Lumpur",
    eligible: true, scholarship: true, mode: "Full-time", faculty: "Faculty of CS & IT",
    description: "A comprehensive programme covering algorithms, software engineering, AI, databases, and systems design.",
    requirements: [
      { subject: "Mathematics", required: "B", yours: "A", met: true },
      { subject: "Physics", required: "B", yours: "A", met: true },
      { subject: "English", required: "C", yours: "B", met: true },
    ],
    fees: { tuition: 25000, registration: 1000, accommodation: 6000, books: 1000, living: 8000 },
    intakes: ["March 2027", "September 2027"],
    careers: ["Software Engineer", "Data Scientist", "AI Engineer", "Systems Architect"],
  },
  {
    id: 2, name: "Bachelor of Software Engineering", institution: "Universiti Teknologi Malaysia", logo: "UTM",
    match: 89, tuition: "RM 21,000", duration: "4 Years", location: "Johor Bahru",
    eligible: true, scholarship: true, mode: "Full-time", faculty: "Faculty of Engineering",
    description: "Focused on software development lifecycle, agile methodologies, cloud computing, and enterprise systems.",
    requirements: [
      { subject: "Mathematics", required: "B", yours: "A", met: true },
      { subject: "Physics", required: "C", yours: "A", met: true },
      { subject: "English", required: "C", yours: "B", met: true },
    ],
    fees: { tuition: 21000, registration: 800, accommodation: 4800, books: 900, living: 7200 },
    intakes: ["September 2027"],
    careers: ["Software Developer", "DevOps Engineer", "Tech Lead"],
  },
  {
    id: 3, name: "Bachelor of Artificial Intelligence", institution: "Asia Pacific University", logo: "APU",
    match: 86, tuition: "RM 28,000", duration: "3 Years", location: "Kuala Lumpur",
    eligible: true, scholarship: false, mode: "Full-time", faculty: "School of Computing",
    description: "Specialises in machine learning, deep learning, NLP, computer vision, and AI ethics.",
    requirements: [
      { subject: "Mathematics", required: "A", yours: "A", met: true },
      { subject: "Physics", required: "B", yours: "A", met: true },
      { subject: "English", required: "B", yours: "B", met: true },
    ],
    fees: { tuition: 28000, registration: 1200, accommodation: 7200, books: 1200, living: 9600 },
    intakes: ["January 2027", "July 2027"],
    careers: ["AI Researcher", "ML Engineer", "Data Scientist"],
  },
  {
    id: 4, name: "Bachelor of Data Science", institution: "Multimedia University", logo: "MMU",
    match: 81, tuition: "RM 18,000", duration: "3 Years", location: "Cyberjaya",
    eligible: false, scholarship: false, mode: "Full-time", faculty: "Faculty of Engineering",
    description: "Combines statistics, programming, and domain expertise to derive insights from complex datasets.",
    requirements: [
      { subject: "Mathematics", required: "A", yours: "A", met: true },
      { subject: "Statistics", required: "B", yours: "N/A", met: false },
      { subject: "English", required: "B", yours: "B", met: true },
    ],
    fees: { tuition: 18000, registration: 750, accommodation: 4200, books: 800, living: 6000 },
    intakes: ["March 2027"],
    careers: ["Data Analyst", "BI Analyst", "Statistician"],
  },
];

export const scholarships = [
  {
    id: 1, name: "Future Technology Scholarship", provider: "ABC Foundation",
    match: 96, type: "Fully Funded", tuition: "100%", living: "RM 1,500/month",
    deadline: "28 Sept 2026", daysLeft: 33,
    programmes: ["Computer Science", "AI", "Data Science"],
    eligibility: { academic: true, mathematics: true, programme: true, institution: true, financial: true, nationality: true },
    description: "Supporting the next generation of technology leaders in Malaysia. Fully covers tuition and provides a generous living allowance.",
    value: 120000, recipients: 25,
  },
  {
    id: 2, name: "National Merit Excellence Award", provider: "Ministry of Education",
    match: 88, type: "Partial Funding", tuition: "70%", living: "RM 800/month",
    deadline: "15 Oct 2026", daysLeft: 50,
    programmes: ["All STEM Programmes"],
    eligibility: { academic: true, mathematics: true, programme: true, institution: true, financial: true, nationality: true },
    description: "Recognising academic excellence among Malaysian students pursuing STEM fields.",
    value: 60000, recipients: 100,
  },
  {
    id: 3, name: "Digital Malaysia Bursary", provider: "MDEC",
    match: 82, type: "Partial Funding", tuition: "50%", living: "RM 600/month",
    deadline: "30 Nov 2026", daysLeft: 96,
    programmes: ["Computer Science", "IT", "Software Engineering"],
    eligibility: { academic: true, mathematics: true, programme: true, institution: false, financial: true, nationality: true },
    description: "Supporting Malaysia's digital economy by funding students in technology programmes.",
    value: 40000, recipients: 200,
  },
  {
    id: 4, name: "Yayasan Petronas Scholarship", provider: "Yayasan Petronas",
    match: 74, type: "Fully Funded", tuition: "100%", living: "RM 1,200/month",
    deadline: "31 Aug 2026", daysLeft: 5,
    programmes: ["Engineering", "Computer Science"],
    eligibility: { academic: true, mathematics: true, programme: true, institution: false, financial: false, nationality: true },
    description: "Petronas scholarship for outstanding students pursuing engineering and technology disciplines.",
    value: 100000, recipients: 50,
  },
];

export const applications = [
  { id: 1, course: "Bachelor of Computer Science", institution: "Universiti Malaya", submitted: "12 Aug 2026", status: "Under Review", steps: ["Submitted", "Doc Verification", "Interview", "Decision"], step: 1, ref: "APP-2026-00142", intake: "March 2027" },
  { id: 2, course: "Bachelor of Software Engineering", institution: "UTM", submitted: "8 Aug 2026", status: "Submitted", steps: ["Submitted", "Doc Verification", "Interview", "Decision"], step: 0, ref: "APP-2026-00128", intake: "September 2027" },
  { id: 3, course: "Future Technology Scholarship", institution: "ABC Foundation", submitted: "1 Aug 2026", status: "Interview", steps: ["Submitted", "Shortlisted", "Interview", "Award"], step: 2, ref: "SCH-2026-00045", intake: "2027" },
];

export const notifications = [
  { id: 1, type: "deadline", text: "Yayasan Petronas Scholarship deadline in 5 days", time: "2h ago", read: false },
  { id: 2, type: "application", text: "Your application to Universiti Malaya has been received", time: "1d ago", read: false },
  { id: 3, type: "course", text: "3 new courses matching your profile were added", time: "2d ago", read: true },
  { id: 4, type: "scholarship", text: "You are now eligible for Digital Malaysia Bursary", time: "3d ago", read: true },
];

export const institutionStats = {
  programmes: 42, applications: 1248, views: 25420, enquiries: 823, scholarships: 15, conversion: "18.4%",
};

export const adminStats = {
  students: 1250000, institutions: 4250, programmes: 85000, scholarships: 12500, applications: 2800000, activeUsers: 85000,
};

export const aiSuggestions = [
  "What can I study with my results?",
  "Which course is the cheapest?",
  "Which scholarships can I get?",
  "Show me fully funded options",
  "What career suits me best?",
  "Why am I not eligible?",
];
