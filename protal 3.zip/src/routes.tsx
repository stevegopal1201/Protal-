import { createBrowserRouter } from "react-router";

import Landing from "./pages/Landing";

import StudentLayout from "./layouts/StudentLayout";
import StudentDashboard from "./pages/student/Dashboard";
import Onboarding from "./pages/student/Onboarding";
import Courses from "./pages/student/Courses";
import CourseDetails from "./pages/student/CourseDetails";
import Recommendations from "./pages/student/Recommendations";
import Scholarships from "./pages/student/Scholarships";
import ScholarshipDetails from "./pages/student/ScholarshipDetails";
import FinancialAid from "./pages/student/FinancialAid";
import Applications from "./pages/student/Applications";
import Documents from "./pages/student/Documents";
import AIAdvisor from "./pages/student/AIAdvisor";
import StudentProfile from "./pages/student/Profile";
import Results from "./pages/student/Results";
import Compare from "./pages/student/Compare";

import InstitutionLayout from "./layouts/InstitutionLayout";
import InstitutionDashboard from "./pages/institution/Dashboard";
import InstitutionProgrammes from "./pages/institution/Programmes";
import InstitutionApplications from "./pages/institution/Applications";
import InstitutionAnalytics from "./pages/institution/Analytics";
import InstitutionProfile from "./pages/institution/Profile";
import InstitutionScholarships from "./pages/institution/Scholarships";

import AdminLayout from "./layouts/AdminLayout";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminUsers from "./pages/admin/Users";
import AdminInstitutions from "./pages/admin/Institutions";
import AIAgents from "./pages/admin/AIAgents";
import Integrations from "./pages/admin/Integrations";
import AdminReports from "./pages/admin/Reports";
import AuditLog from "./pages/admin/AuditLog";

import ScholarshipLayout from "./layouts/ScholarshipLayout";
import ScholarshipDashboard from "./pages/scholarship/Dashboard";
import ScholarshipCreate from "./pages/scholarship/Create";

export const router = createBrowserRouter([
  { path: "/", Component: Landing },

  {
    path: "/student",
    Component: StudentLayout,
    children: [
      { index: true, Component: StudentDashboard },
      { path: "onboarding", Component: Onboarding },
      { path: "courses", Component: Courses },
      { path: "courses/:id", Component: CourseDetails },
      { path: "recommendations", Component: Recommendations },
      { path: "scholarships", Component: Scholarships },
      { path: "scholarships/:id", Component: ScholarshipDetails },
      { path: "financial-aid", Component: FinancialAid },
      { path: "applications", Component: Applications },
      { path: "documents", Component: Documents },
      { path: "ai-advisor", Component: AIAdvisor },
      { path: "profile", Component: StudentProfile },
      { path: "results", Component: Results },
      { path: "compare", Component: Compare },
    ],
  },

  {
    path: "/institution",
    Component: InstitutionLayout,
    children: [
      { index: true, Component: InstitutionDashboard },
      { path: "programmes", Component: InstitutionProgrammes },
      { path: "applications", Component: InstitutionApplications },
      { path: "analytics", Component: InstitutionAnalytics },
      { path: "profile", Component: InstitutionProfile },
      { path: "scholarships", Component: InstitutionScholarships },
    ],
  },

  {
    path: "/admin",
    Component: AdminLayout,
    children: [
      { index: true, Component: AdminDashboard },
      { path: "users", Component: AdminUsers },
      { path: "institutions", Component: AdminInstitutions },
      { path: "ai-agents", Component: AIAgents },
      { path: "integrations", Component: Integrations },
      { path: "reports", Component: AdminReports },
      { path: "audit", Component: AuditLog },
    ],
  },

  {
    path: "/scholarship",
    Component: ScholarshipLayout,
    children: [
      { index: true, Component: ScholarshipDashboard },
      { path: "create", Component: ScholarshipCreate },
    ],
  },
]);
