import { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router";
import { notifications } from "../data/mock";
import logo from "../imports/iooo.png";

const NAV = [
  { to: "/student", label: "Dashboard", icon: "⊞", end: true },
  { to: "/student/profile", label: "My Profile", icon: "👤" },
  { to: "/student/results", label: "My Results", icon: "📊" },
  { to: "/student/courses", label: "Find Courses", icon: "🔍" },
  { to: "/student/recommendations", label: "Recommended", icon: "⭐" },
  { to: "/student/scholarships", label: "Scholarships", icon: "🎓" },
  { to: "/student/financial-aid", label: "Financial Aid", icon: "💰" },
  { to: "/student/applications", label: "Applications", icon: "📋" },
  { to: "/student/documents", label: "Documents", icon: "📁" },
  { to: "/student/ai-advisor", label: "AI Advisor", icon: "🤖" },
];

export default function StudentLayout() {
  const navigate = useNavigate();
  const [notifOpen, setNotifOpen] = useState(false);
  const unread = notifications.filter(n => !n.read).length;

  return (
    <div className="flex h-screen overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Sidebar */}
      <aside className="w-56 shrink-0 flex flex-col overflow-y-auto" style={{ background: "#0B1F3A" }}>
        <div className="px-4 py-4 border-b border-white/10 flex items-center gap-2.5">
          <img src={logo} alt="Edvora" className="w-8 h-8 object-contain shrink-0" />
          <div>
            <p className="text-white font-semibold text-sm leading-none">Edvora</p>
            <p className="text-white/40 text-[10px] mt-0.5">Student Portal</p>
          </div>
        </div>

        <nav className="flex-1 px-2 py-3 space-y-0.5">
          {NAV.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}
            >
              <span className="w-4 text-center shrink-0">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="px-2 pb-3 border-t border-white/10 pt-3 space-y-0.5">
          <p className="text-[10px] text-white/30 font-semibold uppercase tracking-wider px-3 mb-2">Portals</p>
          <button onClick={() => navigate("/institution")} className="nav-link w-full text-left"><span className="w-4 text-center">🏫</span>Institution</button>
          <button onClick={() => navigate("/admin")} className="nav-link w-full text-left"><span className="w-4 text-center">⚙️</span>Administration</button>
        </div>

        <div className="px-4 py-4 border-t border-white/10 flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm font-bold shrink-0">S</div>
          <div className="min-w-0 flex-1">
            <p className="text-white text-xs font-semibold truncate">Steve Lim</p>
            <p className="text-white/40 text-[10px] truncate">steve.lim@email.com</p>
          </div>
          <button onClick={() => navigate("/")} title="Logout" className="w-7 h-7 rounded-lg hover:bg-white/10 flex items-center justify-center text-white/50 hover:text-white transition-colors shrink-0">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-14 bg-white border-b border-slate-200 flex items-center px-6 gap-4 shrink-0">
          <div className="flex-1 max-w-md relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
            <input
              type="text"
              placeholder="Search courses, scholarships, universities…"
              className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-400 focus:bg-white transition-colors"
            />
          </div>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <button
                onClick={() => setNotifOpen(!notifOpen)}
                className="w-9 h-9 rounded-xl bg-slate-50 hover:bg-slate-100 flex items-center justify-center transition-colors relative"
              >
                <span className="text-sm">🔔</span>
                {unread > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">{unread}</span>
                )}
              </button>
              {notifOpen && (
                <div className="absolute right-0 top-11 w-80 bg-white rounded-2xl border border-slate-200 shadow-xl z-50 overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                    <p className="text-sm font-semibold text-slate-800">Notifications</p>
                    <button onClick={() => setNotifOpen(false)} className="text-slate-400 hover:text-slate-600 text-xs">✕</button>
                  </div>
                  {notifications.map(n => (
                    <div key={n.id} className={`px-4 py-3 border-b border-slate-50 hover:bg-slate-50 ${!n.read ? "bg-blue-50/50" : ""}`}>
                      <p className="text-xs text-slate-700">{n.text}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">{n.time}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm font-bold cursor-pointer">S</div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto bg-slate-50">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
