import { NavLink, Outlet, useNavigate } from "react-router";
import logo from "../imports/iooo.png";

const NAV = [
  { to: "/scholarship", label: "Dashboard", icon: "🏠", end: true },
  { to: "/scholarship/create", label: "Create Scholarship", icon: "✨" },
];

export default function ScholarshipLayout() {
  const navigate = useNavigate();
  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <aside className="w-56 shrink-0 flex flex-col" style={{ background: "#0B1F3A" }}>
        <div className="flex items-center gap-2.5 px-4 py-5 border-b border-white/10">
          <img src={logo} alt="Edvora" className="w-8 h-8 object-contain shrink-0" />
          <div>
            <p className="text-white text-xs font-bold leading-none">Edvora</p>
            <p className="text-amber-300 text-[10px] mt-0.5">Scholarship Portal</p>
          </div>
        </div>
        <nav className="flex-1 py-4 px-2 space-y-0.5 overflow-y-auto">
          {NAV.map(item => (
            <NavLink key={item.to} to={item.to} end={item.end}
              className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}>
              <span className="text-base w-5 text-center shrink-0">{item.icon}</span>
              <span className="truncate">{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="px-4 py-4 border-t border-white/10 flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center text-white text-xs font-bold shrink-0">SP</div>
          <div className="min-w-0 flex-1">
            <p className="text-white text-xs font-semibold truncate">ABC Foundation</p>
            <p className="text-white/40 text-[10px] truncate">Scholarship Provider</p>
          </div>
          <button onClick={() => navigate("/")} title="Logout" className="w-7 h-7 rounded-lg hover:bg-white/10 flex items-center justify-center text-white/50 hover:text-white transition-colors shrink-0">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          </button>
        </div>
      </aside>
      <main className="flex-1 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
}
