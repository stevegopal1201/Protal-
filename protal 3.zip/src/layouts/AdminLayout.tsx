import { NavLink, Outlet, useNavigate } from "react-router";
import logo from "../imports/iooo.png";

const NAV = [
  { to: "/admin", label: "Dashboard", icon: "⊞", end: true },
  { to: "/admin/users", label: "Users", icon: "👥" },
  { to: "/admin/institutions", label: "Institutions", icon: "🏫" },
  { to: "/admin/ai-agents", label: "AI Agents", icon: "🤖" },
  { to: "/admin/integrations", label: "Integrations", icon: "🔌" },
  { to: "/admin/reports", label: "Reports", icon: "📊" },
  { to: "/admin/audit", label: "Audit Log", icon: "📋" },
];

export default function AdminLayout() {
  const navigate = useNavigate();
  return (
    <div className="flex h-screen overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <aside className="w-56 shrink-0 flex flex-col overflow-y-auto" style={{ background: "#0B1F3A" }}>
        <div className="px-4 py-4 border-b border-white/10 flex items-center gap-2.5">
          <img src={logo} alt="Edvora" className="w-8 h-8 object-contain shrink-0" />
          <div>
            <p className="text-white font-semibold text-sm leading-none">Edvora</p>
            <p className="text-white/40 text-[10px] mt-0.5">Administration</p>
          </div>
        </div>
        <nav className="flex-1 px-2 py-3 space-y-0.5">
          {NAV.map(item => (
            <NavLink key={item.to} to={item.to} end={item.end}
              className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}>
              <span className="w-4 text-center shrink-0">{item.icon}</span>{item.label}
            </NavLink>
          ))}
        </nav>
        <div className="px-2 pb-3 border-t border-white/10 pt-3 space-y-0.5">
          <p className="text-[10px] text-white/30 font-semibold uppercase tracking-wider px-3 mb-2">Portals</p>
          <button onClick={() => navigate("/student")} className="nav-link w-full text-left"><span className="w-4 text-center">🎓</span>Student</button>
          <button onClick={() => navigate("/institution")} className="nav-link w-full text-left"><span className="w-4 text-center">🏫</span>Institution</button>
        </div>
        <div className="px-4 py-4 border-t border-white/10 flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white text-xs font-bold shrink-0">SA</div>
          <div className="min-w-0 flex-1">
            <p className="text-white text-xs font-semibold truncate">Super Admin</p>
            <p className="text-white/40 text-[10px] truncate">admin@edvora.my</p>
          </div>
          <button onClick={() => navigate("/")} title="Logout" className="w-7 h-7 rounded-lg hover:bg-white/10 flex items-center justify-center text-white/50 hover:text-white transition-colors shrink-0">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          </button>
        </div>
      </aside>
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-14 bg-white border-b border-slate-200 flex items-center px-6 shrink-0">
          <p className="text-sm font-semibold text-slate-700">Administration Portal</p>
          <div className="ml-auto flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-green-500 pulse" />
              <span className="text-xs text-slate-400">All systems operational</span>
            </div>
            <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white text-xs font-bold">SA</div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto bg-slate-50"><Outlet /></main>
      </div>
    </div>
  );
}
