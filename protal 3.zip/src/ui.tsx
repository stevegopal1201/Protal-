/* Shared UI primitives */

// ─── Match Score Ring ────────────────────────────────────────────────────────

export function MatchRing({ score, size = 64 }: { score: number; size?: number }) {
  const sw = 5;
  const r = (size - sw * 2) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ;
  const color = score >= 90 ? "#16A34A" : score >= 75 ? "#2563EB" : score >= 60 ? "#D97706" : "#DC2626";
  const label = score >= 90 ? "Excellent" : score >= 75 ? "Strong" : score >= 60 ? "Good" : "Low";
  const cx = size / 2;
  return (
    <div className="flex flex-col items-center gap-0.5 shrink-0">
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={cx} cy={cx} r={r} fill="none" stroke="#E2E8F0" strokeWidth={sw} />
        <circle cx={cx} cy={cx} r={r} fill="none" stroke={color} strokeWidth={sw}
          strokeLinecap="round" strokeDasharray={`${dash} ${circ - dash}`} />
      </svg>
      <div style={{ marginTop: -(size * 0.6), height: size * 0.6 }} className="flex flex-col items-center justify-center pointer-events-none">
        <span className="font-bold text-slate-800" style={{ fontSize: size * 0.19 }}>{score}%</span>
        {size >= 56 && <span className="text-slate-400 font-medium" style={{ fontSize: size * 0.12 }}>{label}</span>}
      </div>
    </div>
  );
}

// ─── Status Badge ────────────────────────────────────────────────────────────

const STATUS: Record<string, [string, string, string]> = {
  "Eligible":        ["bg-green-50",   "text-green-700",  "bg-green-500"],
  "Highly Eligible": ["bg-green-50",   "text-green-800",  "bg-green-600"],
  "Conditional":     ["bg-amber-50",   "text-amber-700",  "bg-amber-500"],
  "Not Eligible":    ["bg-red-50",     "text-red-700",    "bg-red-500"],
  "Pending":         ["bg-slate-100",  "text-slate-600",  "bg-slate-400"],
  "Approved":        ["bg-green-50",   "text-green-700",  "bg-green-500"],
  "Rejected":        ["bg-red-50",     "text-red-700",    "bg-red-500"],
  "Draft":           ["bg-slate-100",  "text-slate-600",  "bg-slate-400"],
  "Published":       ["bg-blue-50",    "text-blue-700",   "bg-blue-500"],
  "Expired":         ["bg-slate-100",  "text-slate-500",  "bg-slate-300"],
  "Submitted":       ["bg-blue-50",    "text-blue-700",   "bg-blue-500"],
  "Under Review":    ["bg-amber-50",   "text-amber-700",  "bg-amber-500"],
  "Interview":       ["bg-purple-50",  "text-purple-700", "bg-purple-500"],
  "Active":          ["bg-green-50",   "text-green-700",  "bg-green-500"],
  "Fully Funded":    ["bg-green-50",   "text-green-800",  "bg-green-600"],
  "Partial Funding": ["bg-blue-50",    "text-blue-700",   "bg-blue-500"],
  "Suspended":       ["bg-red-50",     "text-red-700",    "bg-red-500"],
  "Verified":        ["bg-green-50",   "text-green-700",  "bg-green-500"],
};

export function Badge({ status, dot = true }: { status: string; dot?: boolean }) {
  const [bg, text, dotBg] = STATUS[status] ?? ["bg-slate-100", "text-slate-600", "bg-slate-400"];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${bg} ${text}`}>
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dotBg}`} />}
      {status}
    </span>
  );
}

// ─── Progress Bar ────────────────────────────────────────────────────────────

export function ProgressBar({ value, color = "#2563EB" }: { value: number; color?: string }) {
  return (
    <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
      <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, background: color }} />
    </div>
  );
}
