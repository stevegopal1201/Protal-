Yes. I can structure the entire product as a Figma-ready UX/UI design system and screen-by-screen prototype specification based on the modules above.

I can’t directly produce a native .fig file in this chat, but the specification below is structured so it can be implemented directly in Figma, including pages, frames, components, variants, navigation, screen fields, states, and prototype flows.

Centralized Education & Course Recommendation Portal

Complete Figma UX/UI Design Specification

Design Scope: Complete web platform
Design Approach: Modern enterprise education ecosystem
Primary Users: Students, Universities/Colleges, Scholarship Providers, Government/Organizations, Administrators
Responsive: Desktop + Tablet + Mobile
Prototype: High-fidelity interactive prototype

⸻

1. FIGMA FILE STRUCTURE

Create one Figma project named:

Centralized Education Platform

Organize the file into the following Figma pages:

00 — Cover & Product Map
01 — Design System
02 — Components
03 — Student — Authentication
04 — Student — Onboarding
05 — Student — Profile
06 — Student — Academic Results
07 — Student — Course Discovery
08 — Student — Recommendations
09 — Student — Course Details
10 — Student — Comparison
11 — Student — Scholarships
12 — Student — Financial Aid
13 — Student — Applications
14 — Student — Documents
15 — Student — AI Advisor
16 — Institution — Authentication
17 — Institution — Dashboard
18 — Institution — Profile
19 — Institution — Campus
20 — Institution — Faculty & Department
21 — Institution — Programmes
22 — Institution — Requirements
23 — Institution — Fees
24 — Institution — Intakes
25 — Institution — Applications
26 — Institution — Analytics
27 — Scholarship Provider
28 — Government / Organization
29 — Platform Administration
30 — Rules & Recommendation Engine
31 — AI & Agents
32 — Integrations
33 — Reports & Analytics
34 — Mobile
35 — Prototype Flows
36 — Empty / Error / Loading States

⸻

2. DESIGN SYSTEM

2.1 Design Philosophy

The interface should feel:

* Trustworthy
* Educational
* Intelligent
* Modern
* Accessible
* Data-driven
* Professional
* Simple for students
* Powerful for administrators

The student experience should be much simpler than the administration experience.

⸻

3. COLOR SYSTEM

Use a professional education-oriented palette.

Primary

* Primary Navy: #0B1F3A
* Primary Blue: #2563EB
* Light Blue: #EFF6FF

Secondary

* Teal: #0F766E
* Green: #16A34A
* Amber: #D97706
* Red: #DC2626
* Purple: #7C3AED

Neutral

* White: #FFFFFF
* Gray 50: #F8FAFC
* Gray 100: #F1F5F9
* Gray 200: #E2E8F0
* Gray 400: #94A3B8
* Gray 600: #475569
* Gray 800: #1E293B
* Black: #0F172A

⸻

4. TYPOGRAPHY

Use:

Inter

Typography:

* Display 1 — 40px / Bold
* Display 2 — 32px / Bold
* H1 — 28px / Bold
* H2 — 24px / Semibold
* H3 — 20px / Semibold
* H4 — 18px / Semibold
* Body Large — 16px
* Body — 14px
* Caption — 12px
* Button — 14px / Semibold

⸻

5. GRID

Desktop:

* Frame: 1440 × 1024
* 12-column grid
* Margin: 64px
* Gutter: 24px

Tablet:

* 1024 × 1366

Mobile:

* 390 × 844
* 4-column grid
* 16px margins

⸻

6. SPACING SYSTEM

Use an 8px spacing system:

4
8
12
16
24
32
40
48
64
80
96

⸻

7. BORDER RADIUS

* Small: 6px
* Medium: 10px
* Large: 16px
* Card: 16px
* Modal: 20px
* Pill: 999px

⸻

8. CORE FIGMA COMPONENTS

Create a dedicated Components page.

Buttons

Variants:

* Primary
* Secondary
* Outline
* Ghost
* Danger
* Success
* Disabled
* Loading

Sizes:

* Small
* Medium
* Large

⸻

Inputs

Components:

* Text Input
* Number Input
* Search
* Dropdown
* Multi-select
* Date Picker
* Time Picker
* Currency
* Percentage
* Grade Selector
* GPA Input
* File Upload
* Text Area

States:

* Default
* Hover
* Focus
* Filled
* Error
* Disabled
* Read Only

⸻

9. STATUS COMPONENTS

Create:

* Eligible
* Highly Eligible
* Conditional
* Potential
* Not Eligible
* Pending
* Approved
* Rejected
* Draft
* Published
* Expired
* Closing Soon

⸻

10. SCORE COMPONENTS

Create reusable:

Match Score Ring

Examples:

94%
Excellent Match

Variants:

* 90–100
* 75–89
* 60–74
* Below 60

Progress Bar

Used for:

* Profile completion
* Academic performance
* Scholarship matching
* Application completion

⸻

11. COURSE CARD

Component:

┌─────────────────────────────────┐
│ Institution Logo                │
│ University Name                 │
│                                 │
│ Bachelor of Computer Science    │
│                                 │
│ 94% Match                       │
│                                 │
│ RM 25,000 / Year                │
│ 3 Years                         │
│ Kuala Lumpur                    │
│                                 │
│ ✓ Eligible                      │
│ 🎓 Scholarship Available        │
│                                 │
│ [View Course] [Save]            │
└─────────────────────────────────┘

⸻

12. SCHOLARSHIP CARD

┌─────────────────────────────────┐
│ Fully Funded                    │
│                                 │
│ Future Technology Scholarship   │
│ ABC Foundation                  │
│                                 │
│ 96% Match                       │
│                                 │
│ Tuition: 100%                   │
│ Living: RM 1,500/month          │
│                                 │
│ Deadline: 28 Sept 2026          │
│                                 │
│ [View] [Apply]                  │
└─────────────────────────────────┘

⸻

13. STUDENT EXPERIENCE

13.1 Student Login

Frame:

Student Login

Fields:

* Email
* Password
* Remember Me

Actions:

* Login
* Forgot Password
* Create Account

⸻

13.2 Student Registration

Fields:

* Full Name
* Email
* Mobile
* Country
* Password
* Confirm Password
* Terms
* Privacy Consent

CTA:

Create Account

⸻

13.3 Student Onboarding

Create a multi-step wizard.

01 Personal
02 Education
03 Results
04 Interests
05 Career
06 Budget
07 Preferences
08 Complete

Progress indicator at top.

⸻

13.4 Personal Information

Fields:

* Full Name
* Date of Birth
* Nationality
* Country
* State
* City
* Email
* Mobile

⸻

13.5 Education Information

Fields:

* School
* Country
* Qualification
* Examination Board
* Examination Year

⸻

13.6 Examination Results

Create an editable results table.

Subject       Grade       Score       Verified
------------------------------------------------
Mathematics   A           85          ✓
English       B           72          ✓
Physics       A           88          ✓
Chemistry     B           76          ✓
Biology       C           65          ✓

Actions:

* Add Subject
* Edit
* Delete
* Upload Certificate
* Scan Certificate

⸻

13.7 Results Upload

Large drag-and-drop area:

Upload Examination Certificate

Supported:

* PDF
* JPG
* PNG

CTA:

Extract Results with AI

After extraction:

Review & Confirm Results

⸻

13.8 Academic Summary

Display:

Overall Performance
A/B Average
Strong Subjects
Mathematics
Physics
Improvement Areas
Biology
Eligible Programme Categories
Computer Science
Engineering
Technology

⸻

14. STUDENT DASHBOARD

Frame:

1440 × 1024

Header:

* Logo
* Search
* Notifications
* Profile

Sidebar:

Dashboard
My Profile
My Results
Recommended Courses
Find Courses
Scholarships
Financial Aid
Applications
Documents
AI Advisor
Saved
Settings

Main dashboard:

Welcome

Good morning, Steve

Profile Completion

92%

Academic Snapshot

* Subjects: 5
* Strongest: Mathematics
* Overall: A/B

Recommended Courses

Show 4 cards.

Scholarships

Show 4 cards.

Deadlines

Show upcoming deadlines.

Applications

Show application status.

⸻

15. COURSE DISCOVERY SCREEN

Header:

Find Your Course

Search bar:

Search courses, subjects, universities…

Filters:

* Country
* City
* Institution
* Programme
* Qualification
* Tuition
* Duration
* Study Mode
* Intake
* Scholarship
* Eligibility

Results:

245 programmes found

Sorting:

* Best Match
* Lowest Cost
* Highest Scholarship
* Most Popular
* Shortest Duration

⸻

16. RECOMMENDED COURSES

Title:

Courses Recommended for You

Tabs:

* Best Matches
* Strong Matches
* Alternative Pathways
* Needs Improvement

Each card contains:

* Match %
* Eligibility
* Cost
* Institution
* Scholarship
* Reason

⸻

17. COURSE DETAILS

Hero:

University Logo
Bachelor of Computer Science
University ABC
94% Match
✓ You are eligible

Tabs:

Overview
Requirements
Fees
Scholarships
Career
Intake
Reviews

⸻

18. COURSE OVERVIEW

Fields displayed:

* Programme description
* Duration
* Qualification
* Study mode
* Campus
* Language
* Accreditation
* Career opportunities

⸻

19. COURSE REQUIREMENTS

Create a requirement comparison table.

Requirement       Required    Your Result    Status
------------------------------------------------------
Mathematics       B           A              ✓
Physics           B           A              ✓
English           C           B              ✓
Qualification     Required    Met            ✓

⸻

20. COURSE FEES

Visual cost breakdown:

Tuition                  RM 25,000
Registration             RM 1,000
Accommodation            RM 6,000
Books                    RM 1,000
Living                   RM 8,000
----------------------------------
Estimated Total          RM 41,000

Then:

Scholarship Opportunities

⸻

21. COURSE COMPARISON

Allow students to select 2–5 programmes.

Columns:

                    Course A      Course B      Course C
----------------------------------------------------------
Match                94%           88%           81%
Eligibility          ✓             ✓             Conditional
Tuition              RM25K         RM21K         RM18K
Duration             3 years       3 years       4 years
Scholarship          Yes           Yes           No
Location             KL            Penang        Johor

⸻

22. SCHOLARSHIP DISCOVERY

Title:

Find Scholarships

Search:

Search scholarships…

Filters:

* Fully Funded
* Tuition
* Living Allowance
* Academic
* Financial Need
* Programme
* Institution
* Country
* Deadline

⸻

23. SCHOLARSHIP RECOMMENDATIONS

Dashboard sections:

Best Matches

Closing Soon

Fully Funded

Partial Funding

Future Opportunities

Each card:

* Match %
* Funding
* Deadline
* Eligibility
* Missing criteria

⸻

24. SCHOLARSHIP DETAILS

Hero:

Future Technology Scholarship

Provider:

ABC Foundation

Display:

* 96% Match
* Fully Funded
* Deadline
* Funding
* Eligible programmes

Tabs:

Overview
Eligibility
Funding
Requirements
Application
Provider

⸻

25. SCHOLARSHIP ELIGIBILITY

Use visual checklist.

Academic Requirement       ✓
Mathematics Requirement    ✓
Programme Requirement      ✓
Institution Requirement    ✓
Financial Requirement      ✓
Nationality Requirement    ✓

⸻

26. FINANCIAL AID SCREEN

Title:

Can I Afford This Programme?

Display:

Total Education Cost
RM 41,000
Scholarship
- RM 20,000
Other Financial Aid
- RM 5,000
Your Estimated Cost
RM 16,000

Then:

Affordable Alternatives

⸻

27. APPLICATION DASHBOARD

Tabs:

* All
* Draft
* Submitted
* Under Review
* Interview
* Accepted
* Rejected

Application card:

Bachelor of Computer Science
University ABC
Submitted: 12 Aug 2026
● Submitted
● Document Verification
○ Interview
○ Decision

⸻

28. APPLICATION FORM

Sections:

Personal Details

Education

Examination

Programme

Documents

Personal Statement

References

Declaration

CTA:

Submit Application

⸻

29. DOCUMENT CENTRE

Screen:

My Documents
✓ Examination Certificate
✓ Transcript
✓ Passport
⚠ Personal Statement
✓ Recommendation Letter

Actions:

* Upload
* Replace
* Preview
* Delete
* Verify

⸻

30. AI EDUCATION ADVISOR

Create a modern conversational interface.

Header:

Education Advisor AI

Example:

“Based on your results, you have 43 suitable computing programmes.”

Suggested questions:

* What can I study?
* Which course is cheapest?
* Which scholarships can I get?
* Why am I not eligible?
* What career suits me?
* Show me fully funded options.

AI response cards should include:

Course
Match
Reason
Cost
Scholarship

⸻

31. CAREER PATHWAY SCREEN

Example:

Your Goal
AI Engineer
       ↓
Recommended Skills
Python
Mathematics
Machine Learning
Cloud
       ↓
Recommended Programmes
Computer Science
AI
Data Science
       ↓
Recommended Institutions
University A
University B
University C

⸻

32. SAVED OPPORTUNITIES

Tabs:

* Courses
* Scholarships
* Institutions

Each item supports:

* Open
* Compare
* Apply
* Remove

⸻

33. NOTIFICATION CENTRE

Categories:

* Courses
* Scholarships
* Applications
* Deadlines
* System

Example:

Scholarship deadline in 7 days.

⸻

34. INSTITUTION PORTAL

Institution Dashboard

Widgets:

Active Programmes       42
Applications            1,248
Course Views            25,420
Student Enquiries       823
Scholarships            15

Charts:

* Applications over time
* Popular programmes
* Student locations
* Conversion rate

⸻

35. INSTITUTION PROFILE

Fields:

* Institution Name
* Logo
* Registration Number
* Accreditation
* Description
* Website
* Contact
* Address
* Campuses
* Facilities
* Social Links

⸻

36. CAMPUS MANAGEMENT

Table:

Campus
Location
Facilities
Accommodation
Status
Actions

CTA:

Add Campus

⸻

37. FACULTY MANAGEMENT

Fields:

* Faculty Name
* Dean
* Description
* Contact
* Departments

⸻

38. DEPARTMENT MANAGEMENT

Fields:

* Department
* Faculty
* Head
* Description
* Contact
* Programmes

⸻

39. PROGRAMME MANAGEMENT

Dashboard:

All Programmes
Draft
Pending Approval
Published
Expired

Table:

* Programme
* Faculty
* Intake
* Fee
* Applications
* Status
* Actions

⸻

40. CREATE PROGRAMME WIZARD

Steps:

01 Basic Information
02 Academic Information
03 Entry Requirements
04 Subjects
05 Fees
06 Intakes
07 Scholarships
08 Preview
09 Submit

⸻

41. PROGRAMME BASIC INFORMATION

Fields:

* Programme Name
* Code
* Qualification
* Level
* Faculty
* Department
* Duration
* Study Mode
* Campus
* Description

⸻

42. PROGRAMME REQUIREMENTS BUILDER

Visual rule builder:

IF
Mathematics >= B
AND
Physics >= B
AND
English >= C
THEN
Eligible

Components:

* Subject
* Operator
* Grade
* AND
* OR
* Add Rule
* Delete Rule

⸻

43. FEE MANAGEMENT

Fields:

* Fee Type
* Amount
* Currency
* Frequency
* Domestic
* International
* Academic Year

⸻

44. INTAKE MANAGEMENT

Fields:

* Intake
* Start Date
* Application Open
* Application Close
* Seats
* Available Seats
* Status

⸻

45. INSTITUTION APPLICATION MANAGEMENT

Application table:

* Student
* Programme
* Date
* Eligibility
* Documents
* Status
* Reviewer

Application detail:

* Student profile
* Academic results
* Documents
* Eligibility analysis
* Notes
* Decision

⸻

46. INSTITUTION ANALYTICS

Charts:

* Programme demand
* Application trends
* Student locations
* Academic profile
* Scholarship interest
* Application conversion

⸻

47. SCHOLARSHIP PROVIDER PORTAL

Dashboard:

Active Scholarships       25
Applications              4,281
Shortlisted               420
Awarded                   85
Funding                   RM 5.2M

⸻

48. CREATE SCHOLARSHIP

Wizard:

01 Basic
02 Eligibility
03 Academic Rules
04 Financial Rules
05 Funding
06 Documents
07 Deadline
08 Preview
09 Publish

⸻

49. SCHOLARSHIP RULE BUILDER

Example:

Academic Grade >= B
AND
Mathematics >= B
AND
Family Income < RM 60,000
AND
Programme IN [Computer Science, AI]

⸻

50. SCHOLARSHIP APPLICATION REVIEW

Screen:

Left:

Student profile

Middle:

Academic results

Right:

Scholarship criteria match

Academic       ✓
Subject        ✓
Income         ✓
Programme      ✓
Documents      ⚠

Actions:

* Shortlist
* Reject
* Request Information
* Approve

⸻

51. GOVERNMENT / ORGANIZATION PORTAL

Dashboard:

* Students
* Institutions
* Programmes
* Scholarships
* Applications
* Funding
* Education Trends

Modules:

Institutions
Programmes
Scholarships
Qualification Framework
Education Data
Analytics
Reports
Integrations

⸻

52. ADMINISTRATION PORTAL

Admin Dashboard

Widgets:

Students              1,250,000
Institutions           4,250
Programmes             85,000
Scholarships           12,500
Applications           2,800,000
Active Users           85,000

System health:

* API
* Database
* Search
* AI
* Integrations
* Notifications

⸻

53. ADMIN USER MANAGEMENT

Table:

* User ID
* Name
* Organization
* Role
* Last Login
* Status
* MFA
* Actions

⸻

54. ADMIN INSTITUTION MANAGEMENT

Table:

* Institution
* Type
* Country
* Accreditation
* Verification
* Programmes
* Status

Actions:

* View
* Verify
* Suspend
* Approve

⸻

55. ADMIN PROGRAMME MANAGEMENT

Filters:

* Institution
* Country
* Faculty
* Qualification
* Status

Actions:

* Review
* Approve
* Reject
* Suspend
* Archive

⸻

56. MASTER DATA MANAGEMENT

Screens:

* Countries
* States
* Cities
* Subjects
* Qualifications
* Examination Boards
* Grades
* Programme Types
* Study Modes
* Scholarship Types

Each screen uses a standard:

Search
Filter
Add
Edit
Delete
Import
Export
Audit

⸻

57. ELIGIBILITY RULE MANAGEMENT

Admin screen:

Rule ID
Programme
Rule Type
Condition
Priority
Version
Effective Date
Status

Rule editor:

IF
Subject = Mathematics
Grade >= B
AND
Subject = Physics
Grade >= B
THEN
Eligible

⸻

58. RECOMMENDATION MANAGEMENT

Dashboard:

Recommendation Engine
Model Version: 1.4
Academic Weight       30%
Subject Weight        20%
Career Weight         15%
Cost Weight           15%
Preference Weight     10%
Location Weight        5%
Availability            5%

CTA:

Edit Recommendation Model

⸻

59. AI & AGENT DASHBOARD

Show:

Student Advisor Agent
● Active
Course Agent
● Active
Scholarship Agent
● Active
Eligibility Agent
● Active
Document Agent
● Active
Data Quality Agent
● Active

Each agent:

* Model
* Version
* Permissions
* Tools
* Data Sources
* Execution Count
* Success Rate
* Errors
* Human Approval

⸻

60. INTEGRATION MANAGEMENT

Screen:

Government API
● Connected
University API
● Connected
Scholarship API
● Connected
Payment Gateway
● Connected
Email
● Connected
SMS
● Connected

Integration detail:

* Provider
* Endpoint
* Authentication
* Sync
* Last Sync
* Error
* Status

⸻

61. DATA QUALITY DASHBOARD

Widgets:

Critical          12
Warnings          84
Expired           125
Missing Data      312
Duplicates        43

Table:

* Entity
* Issue
* Severity
* Owner
* Created
* Status

⸻

62. AUDIT LOG

Fields:

* Timestamp
* User
* Organization
* Action
* Entity
* Entity ID
* Previous Value
* New Value
* IP
* Result

⸻

63. REPORTING

Report catalogue:

Student Reports

* Academic Profile
* Recommendation Report
* Scholarship Report
* Financial Report

Institution

* Programme Performance
* Application Report
* Demand Report

Scholarship

* Application Report
* Award Report
* Funding Report

Government

* Education Demand
* Skills Demand
* Scholarship Distribution
* Regional Analysis

⸻

64. EMPTY STATES

Create reusable screens:

* No courses
* No scholarships
* No applications
* No documents
* No notifications
* No search results
* No recommendations

Example:

We couldn’t find a matching course.

CTA:

Adjust Your Preferences

⸻

65. ERROR STATES

Create:

* 404
* 403
* 500
* Network Error
* Session Expired
* Validation Error
* Upload Error
* Integration Error

⸻

66. LOADING STATES

Create skeleton components for:

* Dashboard
* Course cards
* Scholarship cards
* Search
* Tables
* Recommendation engine
* AI response

⸻

67. MOBILE DESIGN

Mobile bottom navigation:

Home
Courses
Scholarships
Applications
Profile

Mobile dashboard:

Welcome
Profile 92%
Top Course Match
94%
Top Scholarship
96%
Upcoming Deadline
Applications

⸻

68. RESPONSIVE BEHAVIOR

Desktop:

* Left sidebar
* Multi-column cards
* Full tables

Tablet:

* Collapsible sidebar
* Two-column cards
* Horizontal tables

Mobile:

* Bottom navigation
* Single-column cards
* Accordion sections
* Horizontal scrolling comparison
* Full-screen forms

⸻

69. PRIMARY PROTOTYPE FLOW

Create a clickable Figma prototype:

Landing
   ↓
Student Registration
   ↓
Onboarding
   ↓
Personal Profile
   ↓
Education
   ↓
Examination Results
   ↓
Interests
   ↓
Career
   ↓
Budget
   ↓
Analysis
   ↓
Student Dashboard
   ↓
Recommended Courses
   ↓
Course Details
   ↓
Eligibility
   ↓
Course Comparison
   ↓
Scholarship Matches
   ↓
Scholarship Details
   ↓
Financial Analysis
   ↓
Application
   ↓
Documents
   ↓
Submit
   ↓
Application Tracking

⸻

70. SECONDARY PROTOTYPE FLOW

Institution:

Institution Registration
        ↓
Verification
        ↓
Institution Dashboard
        ↓
Create Programme
        ↓
Entry Requirements
        ↓
Subject Rules
        ↓
Fees
        ↓
Intake
        ↓
Scholarship
        ↓
Preview
        ↓
Submit
        ↓
Approval
        ↓
Publish

⸻

71. SCHOLARSHIP PROTOTYPE FLOW

Provider Registration
        ↓
Provider Dashboard
        ↓
Create Scholarship
        ↓
Eligibility Rules
        ↓
Funding
        ↓
Documents
        ↓
Deadline
        ↓
Publish
        ↓
Student Matching
        ↓
Applications
        ↓
Review
        ↓
Shortlist
        ↓
Award

⸻

72. FIGMA COMPONENT NAMING STANDARD

Use consistent component names:

Button/Primary/Large
Button/Secondary/Medium
Input/Text/Default
Input/Text/Error
Input/Select/Default
Card/Course/Default
Card/Course/Recommended
Card/Scholarship/Default
Badge/Eligibility/Eligible
Badge/Eligibility/Conditional
Badge/Status/Published
Table/Programme
Table/Application
Modal/Confirmation
Drawer/Filters
Navigation/Sidebar
Navigation/Topbar
Score/Match
Chart/Line
Chart/Bar
Chart/Donut

⸻

73. FIGMA VARIABLES

Create variables for:

Colors

color.primary
color.secondary
color.success
color.warning
color.error
color.background
color.surface
color.text.primary
color.text.secondary

Spacing

space.1
space.2
space.3
space.4
space.6
space.8
space.12

Radius

radius.sm
radius.md
radius.lg
radius.xl
radius.full

⸻

74. DESIGN TOKENS

Every component should use variables rather than manually entered values.

This allows:

* Global theme changes
* Dark mode
* Government branding
* Institution branding
* White-label deployments

⸻

75. WHITE-LABEL SUPPORT

The architecture should allow institutions or government partners to have configurable branding:

* Logo
* Primary color
* Secondary color
* Favicon
* Email branding
* Portal name

The underlying UX remains consistent.

⸻

76. ACCESSIBILITY DESIGN

Figma designs must account for:

* Keyboard navigation
* Screen reader labels
* Focus states
* Error messages
* Sufficient contrast
* Accessible form labels
* Accessible tables
* Accessible charts
* Large touch targets

⸻

77. FINAL FIGMA FRAME INVENTORY

The complete design should contain approximately:

Student

60+ screens

Institution

40+ screens

Scholarship Provider

25+ screens

Government/Organization

15+ screens

Administration

50+ screens

Shared

30+ screens

Mobile

30+ responsive screens

Total

250+ Figma frames/screens, including major workflows, details, forms, states and responsive variants.

⸻

78. FINAL FIGMA INFORMATION ARCHITECTURE

CENTRAL EDUCATION PLATFORM
│
├── STUDENT
│   ├── Profile
│   ├── Education
│   ├── Examination
│   ├── Course Discovery
│   ├── Recommendation
│   ├── Eligibility
│   ├── Comparison
│   ├── Scholarships
│   ├── Financial Aid
│   ├── Applications
│   ├── Documents
│   ├── Career
│   └── AI Advisor
│
├── INSTITUTION
│   ├── Institution
│   ├── Campus
│   ├── Faculty
│   ├── Department
│   ├── Programme
│   ├── Requirements
│   ├── Fees
│   ├── Intake
│   ├── Scholarship
│   └── Applications
│
├── SCHOLARSHIP PROVIDER
│   ├── Provider
│   ├── Scholarship
│   ├── Eligibility
│   ├── Applications
│   ├── Shortlist
│   └── Awards
│
├── GOVERNMENT
│   ├── Institutions
│   ├── Qualifications
│   ├── Programmes
│   ├── Scholarships
│   └── Analytics
│
└── ADMIN
    ├── Users
    ├── Institutions
    ├── Programmes
    ├── Scholarships
    ├── Master Data
    ├── Rules
    ├── Recommendation
    ├── AI Agents
    ├── Integrations
    ├── Data Quality
    ├── Security
    ├── Audit
    └── Reports

79. DESIGN PRINCIPLE FOR THE FINAL PROTOTYPE

The most important Figma experience should be the student’s first 10-minute journey:

Create Profile → Enter Results → Tell Us Your Interests → Analyze → Receive Course Recommendations → Understand Why → See Cost → Find Scholarships → Compare → Apply

The student should never need to understand the complexity of the underlying eligibility engine, recommendation engine, rules engine, AI agents, integrations or data architecture.

The complexity belongs behind the interface; the student experience should remain simple:

“Tell us about yourself. We will help you find the right education pathway and funding opportunities.”